import { supabase } from './supabase'
import type { Profile } from '../types'

export interface SignUpData {
  fullName: string
  username: string
  email: string
  password: string
}

/** Inscription : crée l'utilisateur Auth + son profil. */
export async function signUp(data: SignUpData): Promise<{ error: string | null }> {
  // Vérification de l'unicité du pseudonyme avant création
  const { data: existing } = await supabase
    .from('profiles')
    .select('id')
    .eq('username', data.username.toLowerCase())
    .maybeSingle()
  if (existing) return { error: "Ce pseudonyme est déjà utilisé." }

  const { data: res, error } = await supabase.auth.signUp({
    email: data.email,
    password: data.password,
    options: {
      data: { full_name: data.fullName, username: data.username.toLowerCase() },
    },
  })
  if (error) {
    if (error.message.includes('already registered'))
      return { error: 'Cet email est déjà inscrit.' }
    return { error: error.message }
  }
  if (!res.user) return { error: 'Inscription impossible, réessayez.' }

  // Création du profil (si le trigger DB ne l'a pas déjà fait)
  const { error: pErr } = await supabase.from('profiles').upsert({
    id: res.user.id,
    username: data.username.toLowerCase(),
    full_name: data.fullName,
    email: data.email,
    bio: '',
  })
  if (pErr && !pErr.message.includes('duplicate')) return { error: pErr.message }
  return { error: null }
}

export async function signIn(email: string, password: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.signInWithPassword({ email, password })
  if (error) {
    if (error.message.includes('Invalid login credentials'))
      return { error: 'Email ou mot de passe incorrect.' }
    return { error: error.message }
  }
  return { error: null }
}

export async function signOut(): Promise<void> {
  await supabase.auth.signOut()
}

export async function resetPassword(email: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${window.location.origin}/reset-password`,
  })
  return { error: error ? error.message : null }
}

export async function updatePassword(newPassword: string): Promise<{ error: string | null }> {
  const { error } = await supabase.auth.updateUser({ password: newPassword })
  return { error: error ? error.message : null }
}

export async function getSessionUserId(): Promise<string | null> {
  const { data } = await supabase.auth.getSession()
  return data.session?.user.id ?? null
}

/** Met à jour le profil, avec téléversement optionnel de l'avatar. */
export async function updateProfile(
  userId: string,
  updates: { full_name?: string; username?: string; bio?: string; avatarFile?: File | null },
  currentAvatarUrl?: string | null
): Promise<{ error: string | null }> {
  const payload: Record<string, unknown> = {}
  if (updates.full_name !== undefined) payload.full_name = updates.full_name
  if (updates.username !== undefined) payload.username = updates.username.toLowerCase()
  if (updates.bio !== undefined) payload.bio = updates.bio

  if (updates.avatarFile) {
    const file = updates.avatarFile
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
    const path = `${userId}/avatar-${Date.now()}.${ext}`
    const { error: upErr } = await supabase.storage
      .from('avatars')
      .upload(path, file, { cacheControl: '3600', upsert: false })
    if (upErr) return { error: "Échec du téléversement de la photo : " + upErr.message }
    const { data: pub } = supabase.storage.from('avatars').getPublicUrl(path)
    payload.avatar_url = pub.publicUrl
    // Nettoyage de l'ancien avatar
    if (currentAvatarUrl && currentAvatarUrl.includes('/avatars/')) {
      const oldPath = currentAvatarUrl.split('/avatars/')[1]
      if (oldPath) supabase.storage.from('avatars').remove([oldPath]).catch(() => {})
    }
  }

  const { error } = await supabase.from('profiles').update(payload).eq('id', userId)
  if (error) {
    if (error.code === '23505') return { error: 'Ce pseudonyme est déjà utilisé.' }
    return { error: error.message }
  }
  return { error: null }
}

export async function getProfileByUsername(username: string): Promise<Profile | null> {
  const { data } = await supabase
    .from('profiles')
    .select('*')
    .ilike('username', username)
    .maybeSingle()
  return data
}

export async function getProfileById(id: string): Promise<Profile | null> {
  const { data } = await supabase.from('profiles').select('*').eq('id', id).maybeSingle()
  return data
}

export async function searchProfiles(query: string, limit = 20): Promise<Profile[]> {
  const q = query.trim().replace(/[%,()]/g, '')
  if (!q) return []
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .or(`username.ilike.%${q}%,full_name.ilike.%${q}%`)
    .limit(limit)
  if (error) return []
  return data ?? []
}
