import { supabase } from './supabase'
import type { Conversation, Message, Profile } from '../types'

const MSG_AUDIO_BUCKET = 'voice-messages'

/** Récupère les conversations de l'utilisateur, avec profil des participants et dernier message. */
export async function getConversations(userId: string): Promise<Conversation[]> {
  const { data: links, error } = await supabase
    .from('conversation_participants')
    .select('conversation_id, conversations(*)')
    .eq('user_id', userId)
    .order('updated_at', { ascending: false })
  if (error || !links) return []

  const convIds = links.map((l: Record<string, unknown>) => (l.conversation_id as string))
  if (!convIds.length) return []

  const [{ data: parts }, lastMessagesResult] = await Promise.all([
    supabase
      .from('conversation_participants')
      .select('conversation_id, profiles(*)')
      .in('conversation_id', convIds),
    getConversationsLastMessages(convIds),
  ])

  const byConv = new Map<string, Profile[]>()
  for (const p of parts ?? []) {
    const cid = (p as Record<string, unknown>).conversation_id as string
    const prof = (p as Record<string, unknown>).profiles as Profile
    if (!byConv.has(cid)) byConv.set(cid, [])
    if (prof) byConv.get(cid)!.push(prof)
  }

  const result: Conversation[] = convIds.map((cid) => ({
    id: cid,
    created_at: '',
    participants: (byConv.get(cid) ?? []).map((p) => p.id),
    participant_profiles: byConv.get(cid) ?? [],
    last_message: lastMessagesResult.get(cid) ?? null,
  }))

  // Tri par date du dernier message
  result.sort((a, b) =>
    (b.last_message?.created_at ?? '').localeCompare(a.last_message?.created_at ?? '')
  )
  return result
}

async function getConversationsLastMessages(convIds: string[]): Promise<Map<string, Message>> {
  const map = new Map<string, Message>()
  if (!convIds.length) return map
  const { data } = await supabase
    .from('messages')
    .select('*')
    .in('conversation_id', convIds)
    .order('created_at', { ascending: false })
  for (const m of data ?? []) {
    const msg = m as Message
    if (!map.has(msg.conversation_id)) map.set(msg.conversation_id, msg)
  }
  return map
}

/** Trouve ou crée une conversation privée entre deux utilisateurs. */
export async function findOrCreateConversation(
  userId: string,
  otherUserId: string
): Promise<{ conversationId: string | null; error: string | null }> {
  if (userId === otherUserId)
    return { conversationId: null, error: 'Impossible de vous écrire à vous-même.' }

  const { data: existing } = await supabase
    .from('conversations')
    .select('id, conversation_participants(user_id)')
  const found = (existing ?? []).find((c: Record<string, unknown>) => {
    const parts = (c.conversation_participants as { user_id: string }[]) ?? []
    const ids = parts.map((p) => p.user_id)
    return ids.includes(userId) && ids.includes(otherUserId) && ids.length === 2
  })
  if (found) return { conversationId: found.id as string, error: null }

  const { data: conv, error: cErr } = await supabase
    .from('conversations')
    .insert({})
    .select('id')
    .single()
  if (cErr || !conv) return { conversationId: null, error: cErr?.message ?? 'Erreur création conversation.' }

  const { error: pErr } = await supabase.from('conversation_participants').insert([
    { conversation_id: conv.id, user_id: userId },
    { conversation_id: conv.id, user_id: otherUserId },
  ])
  if (pErr) return { conversationId: null, error: pErr.message }
  return { conversationId: conv.id as string, error: null }
}

export async function getMessages(conversationId: string, limit = 100): Promise<Message[]> {
  const { data, error } = await supabase
    .from('messages')
    .select('*, sender:profiles!messages_sender_id_fkey ( id, username, full_name, avatar_url, bio, created_at )')
    .eq('conversation_id', conversationId)
    .order('created_at', { ascending: true })
    .limit(limit)
  if (error) return []
  return (data ?? []) as unknown as Message[]
}

export async function sendTextMessage(
  conversationId: string,
  senderId: string,
  content: string
): Promise<{ error: string | null }> {
  const text = content.trim()
  if (!text) return { error: 'Message vide.' }
  if (text.length > 4000) return { error: 'Message trop long.' }
  const { error } = await supabase.from('messages').insert({
    conversation_id: conversationId,
    sender_id: senderId,
    content: text,
    type: 'text',
  })
  if (!error) await touchConversation(conversationId)
  return { error: error ? error.message : null }
}

const MAX_AUDIO_SIZE = 2 * 1024 * 1024 // ~2 Mo ≈ plusieurs minutes

/** Envoie un message vocal : téléverse l'audio dans Storage puis insère le message. */
export async function sendAudioMessage(
  conversationId: string,
  senderId: string,
  blob: Blob,
  durationSec: number
): Promise<{ error: string | null }> {
  if (blob.size > MAX_AUDIO_SIZE)
    return { error: 'Enregistrement trop long (max ~2 Mo).' }
  const ext = blob.type.includes('webm') ? 'webm' : blob.type.includes('ogg') ? 'ogg' : 'mp4'
  const path = `${senderId}/${conversationId}-${Date.now()}.${ext}`
  const { error: upErr } = await supabase.storage
    .from(MSG_AUDIO_BUCKET)
    .upload(path, blob, { contentType: blob.type, upsert: false })
  if (upErr) return { error: "Échec du téléversement vocal : " + upErr.message }

  const { error } = await supabase.from('messages').insert({
    conversation_id: conversationId,
    sender_id: senderId,
    content: '[Message vocal]',
    type: 'audio',
    audio_path: path,
    duration: Math.round(durationSec),
  })
  if (error) {
    supabase.storage.from(MSG_AUDIO_BUCKET).remove([path]).catch(() => {})
    return { error: error.message }
  }
  await touchConversation(conversationId)
  return { error: null }
}

/** URL signée pour lire un message vocal (bucket privé). */
export async function getAudioUrl(storagePath: string): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from(MSG_AUDIO_BUCKET)
    .createSignedUrl(storagePath, 60 * 60)
  if (error) return null
  return data.signedUrl
}

async function touchConversation(conversationId: string): Promise<void> {
  await supabase
    .from('conversations')
    .update({ updated_at: new Date().toISOString() })
    .eq('id', conversationId)
}

export async function markMessagesRead(conversationId: string, userId: string): Promise<void> {
  const { data } = await supabase
    .from('messages')
    .select('id, read_by, sender_id')
    .eq('conversation_id', conversationId)
    .neq('sender_id', userId)
  for (const m of data ?? []) {
    const readBy = (m.read_by as string[]) ?? []
    if (!readBy.includes(userId)) {
      await supabase
        .from('messages')
        .update({ read_by: [...readBy, userId] })
        .eq('id', m.id as string)
    }
  }
}

export function onNewMessage(
  conversationId: string,
  callback: (msg: Message) => void
): () => void {
  const channel = supabase
    .channel(`messages-${conversationId}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
      (payload) => callback(payload.new as Message)
    )
    .subscribe()
  return () => {
    supabase.removeChannel(channel)
  }
}

export function onAnyMessage(userId: string, callback: (msg: Message) => void): () => void {
  const channel = supabase
    .channel(`all-messages-${userId}`)
    .on(
      'postgres_changes',
      { event: 'INSERT', schema: 'public', table: 'messages' },
      (payload) => callback(payload.new as Message)
    )
    .subscribe()
  return () => {
    supabase.removeChannel(channel)
  }
}

// --- Indicateur de saisie via Realtime (presence) ---

export function typingChannel(conversationId: string) {
  return supabase.channel(`typing-${conversationId}`, {
    config: { presence: { key: crypto.randomUUID() } },
  })
}
