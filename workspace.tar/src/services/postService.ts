import { supabase } from './supabase'
import type { Post, Comment, Profile } from '../types'

const POST_SELECT = `
  id, user_id, content, created_at,
  author:profiles!posts_user_id_fkey ( id, username, full_name, avatar_url, bio, created_at ),
  images:post_images ( id, post_id, url, storage_path ),
  likes ( id, user_id )
`

interface RawPost extends Record<string, unknown> {
  id: string
  user_id: string
  content: string
  created_at: string
  author: Profile | null
  images: { id: string; post_id: string; url: string; storage_path: string | null }[]
  likes: { id: string; user_id: string }[]
  comments?: { id: string }[]
}

function mapPost(raw: RawPost, viewerId: string | null): Post {
  return {
    id: raw.id,
    user_id: raw.user_id,
    content: raw.content,
    created_at: raw.created_at,
    author: raw.author ?? undefined,
    images: raw.images?.sort((a, b) => a.id.localeCompare(b.id)) ?? [],
    likes_count: raw.likes?.length ?? 0,
    liked_by_me: viewerId ? (raw.likes ?? []).some((l) => l.user_id === viewerId) : false,
    comments_count: raw.comments?.length,
  }
}

/** Fil d'actualité paginé. Si followingOnly=true, publications des utilisateurs suivis + soi. */
export async function getFeed(
  viewerId: string | null,
  page = 0,
  pageSize = 10,
  followingOnly = false
): Promise<Post[]> {
  let query = supabase
    .from('posts')
    .select(`${POST_SELECT}, comments ( id )`)
    .order('created_at', { ascending: false })
    .range(page * pageSize, page * pageSize + pageSize - 1)

  if (followingOnly && viewerId) {
    const { data: follows } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', viewerId)
    const ids = [viewerId, ...(follows ?? []).map((f) => f.following_id)]
    query = query.in('user_id', ids)
  }

  const { data, error } = await query
  if (error) {
    console.error('getFeed', error)
    return []
  }
  return (data as unknown as RawPost[]).map((p) => mapPost(p, viewerId))
}

/** Publications récentes (page Découvrir). */
export async function getRecentPosts(viewerId: string | null, limit = 20): Promise<Post[]> {
  const { data, error } = await supabase
    .from('posts')
    .select(`${POST_SELECT}, comments ( id )`)
    .order('created_at', { ascending: false })
    .limit(limit)
  if (error) return []
  return (data as unknown as RawPost[]).map((p) => mapPost(p, viewerId))
}

/** Publications d'un utilisateur. */
export async function getUserPosts(userId: string, viewerId: string | null): Promise<Post[]> {
  const { data, error } = await supabase
    .from('posts')
    .select(`${POST_SELECT}, comments ( id )`)
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
  if (error) return []
  return (data as unknown as RawPost[]).map((p) => mapPost(p, viewerId))
}

export async function getPostById(postId: string, viewerId: string | null): Promise<Post | null> {
  const { data, error } = await supabase
    .from('posts')
    .select(`${POST_SELECT}, comments ( id )`)
    .eq('id', postId)
    .maybeSingle()
  if (error || !data) return null
  return mapPost(data as unknown as RawPost, viewerId)
}

const MAX_IMAGE_SIZE = 5 * 1024 * 1024 // 5 Mo
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']

/** Crée une publication avec texte et/ou images (max 4). */
export async function createPost(
  userId: string,
  content: string,
  files: File[]
): Promise<{ error: string | null }> {
  if (!content.trim() && files.length === 0)
    return { error: 'Votre publication est vide.' }
  if (files.length > 4) return { error: 'Maximum 4 images par publication.' }

  for (const f of files) {
    if (!ALLOWED_TYPES.includes(f.type))
      return { error: `Format non supporté : ${f.name} (JPG, PNG, WEBP ou GIF uniquement).` }
    if (f.size > MAX_IMAGE_SIZE)
      return { error: `Fichier trop volumineux : ${f.name} (max 5 Mo).` }
  }

  const { data: post, error } = await supabase
    .from('posts')
    .insert({ user_id: userId, content: content.trim() })
    .select('id')
    .single()
  if (error || !post) return { error: error?.message ?? 'Erreur de création.' }

  for (const file of files) {
    const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg'
    const path = `${userId}/${post.id}-${crypto.randomUUID()}.${ext}`
    const { error: upErr } = await supabase.storage
      .from('posts-media')
      .upload(path, file, { cacheControl: '3600', upsert: false })
    if (upErr) {
      await supabase.from('posts').delete().eq('id', post.id)
      return { error: "Échec du téléversement d'image : " + upErr.message }
    }
    const { data: pub } = supabase.storage.from('posts-media').getPublicUrl(path)
    const { error: imgErr } = await supabase
      .from('post_images')
      .insert({ post_id: post.id, url: pub.publicUrl, storage_path: path })
    if (imgErr) {
      await supabase.storage.from('posts-media').remove([path])
    }
  }
  return { error: null }
}

export async function deletePost(postId: string, userId: string): Promise<{ error: string | null }> {
  const { data: imgs } = await supabase
    .from('post_images')
    .select('storage_path')
    .eq('post_id', postId)
  const paths = (imgs ?? []).map((i) => i.storage_path).filter(Boolean) as string[]
  if (paths.length) await supabase.storage.from('posts-media').remove(paths)
  const { error } = await supabase.from('posts').delete().eq('id', postId).eq('user_id', userId)
  return { error: error ? error.message : null }
}

export async function toggleLike(postId: string, userId: string): Promise<{ liked: boolean; error: string | null }> {
  const { data: existing } = await supabase
    .from('likes')
    .select('id')
    .eq('post_id', postId)
    .eq('user_id', userId)
    .maybeSingle()
  if (existing) {
    const { error } = await supabase.from('likes').delete().eq('id', existing.id)
    return { liked: false, error: error ? error.message : null }
  }
  const { error } = await supabase.from('likes').insert({ post_id: postId, user_id: userId })
  return { liked: true, error: error ? error.message : null }
}

export async function getComments(postId: string): Promise<Comment[]> {
  const { data, error } = await supabase
    .from('comments')
    .select('*, author:profiles ( id, username, full_name, avatar_url, bio, created_at )')
    .eq('post_id', postId)
    .order('created_at', { ascending: true })
  if (error) return []
  return (data ?? []) as unknown as Comment[]
}

export async function addComment(postId: string, userId: string, content: string): Promise<{ error: string | null }> {
  const text = content.trim()
  if (!text) return { error: 'Commentaire vide.' }
  if (text.length > 1000) return { error: 'Commentaire trop long (max 1000 caractères).' }
  const { error } = await supabase
    .from('comments')
    .insert({ post_id: postId, user_id: userId, content: text })
  return { error: error ? error.message : null }
}

export async function deleteComment(commentId: string, userId: string): Promise<{ error: string | null }> {
  const { error } = await supabase.from('comments').delete().eq('id', commentId).eq('user_id', userId)
  return { error: error ? error.message : null }
}
