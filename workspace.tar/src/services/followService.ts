import { supabase } from './supabase'
import type { Profile } from '../types'

export async function isFollowing(followerId: string, followingId: string): Promise<boolean> {
  const { data } = await supabase
    .from('follows')
    .select('id')
    .eq('follower_id', followerId)
    .eq('following_id', followingId)
    .maybeSingle()
  return Boolean(data)
}

export async function toggleFollow(
  followerId: string,
  followingId: string
): Promise<{ following: boolean; error: string | null }> {
  if (followerId === followingId) return { following: false, error: 'Impossible de vous suivre vous-même.' }
  const already = await isFollowing(followerId, followingId)
  if (already) {
    const { error } = await supabase
      .from('follows')
      .delete()
      .eq('follower_id', followerId)
      .eq('following_id', followingId)
    return { following: false, error: error ? error.message : null }
  }
  const { error } = await supabase
    .from('follows')
    .insert({ follower_id: followerId, following_id: followingId })
  return { following: true, error: error ? error.message : null }
}

export interface ProfileStats {
  posts: number
  followers: number
  following: number
}

export async function getProfileStats(userId: string): Promise<ProfileStats> {
  const [postsRes, followersRes, followingRes] = await Promise.all([
    supabase.from('posts').select('id', { count: 'exact', head: true }).eq('user_id', userId),
    supabase.from('follows').select('id', { count: 'exact', head: true }).eq('following_id', userId),
    supabase.from('follows').select('id', { count: 'exact', head: true }).eq('follower_id', userId),
  ])
  return {
    posts: postsRes.count ?? 0,
    followers: followersRes.count ?? 0,
    following: followingRes.count ?? 0,
  }
}

/** Suggestions de comptes à suivre (non suivis, populaires). */
export async function getSuggestions(viewerId: string | null, limit = 5): Promise<Profile[]> {
  let query = supabase.from('profiles').select('*').neq('id', viewerId ?? '').limit(limit * 3)
  const { data } = await query
  const profiles = (data ?? []) as Profile[]
  if (!viewerId || profiles.length === 0) return profiles.slice(0, limit)
  const { data: follows } = await supabase
    .from('follows')
    .select('following_id')
    .eq('follower_id', viewerId)
  const followedIds = new Set((follows ?? []).map((f) => f.following_id))
  return profiles.filter((p) => !followedIds.has(p.id)).slice(0, limit)
}

/** Liste des abonnés / abonnements d'un utilisateur. */
export async function getConnections(
  userId: string,
  kind: 'followers' | 'following'
): Promise<Profile[]> {
  const { data } = await supabase
    .from('follows')
    .select(kind === 'followers' ? 'follower_id' : 'following_id')
    .eq(kind === 'followers' ? 'following_id' : 'follower_id', userId)
  const ids = (data ?? []).map((r) =>
    kind === 'followers' ? (r as Record<string, string>).follower_id : (r as Record<string, string>).following_id
  )
  if (!ids.length) return []
  const { data: profiles } = await supabase.from('profiles').select('*').in('id', ids)
  return (profiles ?? []) as Profile[]
}
