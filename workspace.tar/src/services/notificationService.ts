import { supabase } from './supabase'
import type { AppNotification } from '../types'

export async function getNotifications(userId: string, limit = 30): Promise<AppNotification[]> {
  const { data, error } = await supabase
    .from('notifications')
    .select('*, actor:profiles!notifications_actor_id_fkey ( id, username, full_name, avatar_url, bio, created_at )')
    .eq('user_id', userId)
    .order('created_at', { ascending: false })
    .limit(limit)
  if (error) return []
  return (data ?? []) as unknown as AppNotification[]
}

export async function getUnreadCount(userId: string): Promise<number> {
  const { count, error } = await supabase
    .from('notifications')
    .select('id', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('is_read', false)
  if (error) return 0
  return count ?? 0
}

export async function markAllRead(userId: string): Promise<void> {
  await supabase
    .from('notifications')
    .update({ is_read: true })
    .eq('user_id', userId)
}

export async function markOneRead(id: string): Promise<void> {
  await supabase.from('notifications').update({ is_read: true }).eq('id', id)
}

/** Crée une notification (appelé depuis le client ; RLS autorise l'insertion par l'acteur). */
export async function createNotification(params: {
  user_id: string
  actor_id: string
  type: AppNotification['type']
  post_id?: string | null
  conversation_id?: string | null
  comment_id?: string | null
}): Promise<void> {
  if (params.user_id === params.actor_id) return // pas de auto-notification
  await supabase.from('notifications').insert(params)
}

export function onNewNotification(
  userId: string,
  callback: (n: AppNotification) => void
): () => void {
  const channel = supabase
    .channel(`notifications-${userId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'notifications',
        filter: `user_id=eq.${userId}`,
      },
      (payload) => callback(payload.new as AppNotification)
    )
    .subscribe()
  return () => {
    supabase.removeChannel(channel)
  }
}
