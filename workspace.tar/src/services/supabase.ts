import { createClient } from '@supabase/supabase-js'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined

if (!supabaseUrl || !supabaseAnonKey) {
  // Affiche un avertissement clair dans la console si le .env n'est pas configuré.
  console.warn(
    '⚠️ NEXORA : VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY manquants. ' +
      'Copiez .env.example en .env et renseignez vos clés Supabase.'
  )
}

export const isSupabaseConfigured = Boolean(supabaseUrl && supabaseAnonKey)

export const BUCKET_AVATARS = (import.meta.env.VITE_STORAGE_BUCKET_AVATARS as string) || 'avatars'
export const BUCKET_POSTS = (import.meta.env.VITE_STORAGE_BUCKET_POSTS as string) || 'posts-media'

export const supabase = createClient(
  supabaseUrl || 'http://localhost:54321',
  supabaseAnonKey || 'missing-anon-key',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: true,
    },
    realtime: {
      params: { eventsPerSecond: 10 },
    },
  }
)
