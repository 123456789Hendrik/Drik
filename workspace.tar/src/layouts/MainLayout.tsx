import { useState } from 'react'
import { Link, Outlet, useNavigate } from 'react-router-dom'
import { ArrowLeft, Search, Loader2 } from 'lucide-react'
import { Sidebar, TopBar, BottomNav } from '../components/Navigation'
import { useAuth } from '../contexts/AuthContext'
import Avatar from '../components/Avatar'
import { searchProfiles } from '../services/authService'
import type { Profile } from '../types'

export function MainLayout() {
  const { loading } = useAuth()
  const navigate = useNavigate()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Profile[] | null>(null)
  const [searching, setSearching] = useState(false)

  const runSearch = async (q: string) => {
    setQuery(q)
    if (q.trim().length < 2) {
      setResults(null)
      return
    }
    setSearching(true)
    const r = await searchProfiles(q)
    setResults(r)
    setSearching(false)
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-night">
        <Loader2 className="animate-spin text-primary-400" size={36} />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-night text-slate-100">
      {/* Fond décoratif */}
      <div className="pointer-events-none fixed inset-0 overflow-hidden">
        <div className="absolute -top-40 left-1/4 h-96 w-96 rounded-full bg-primary/10 blur-[120px]" />
        <div className="absolute bottom-0 right-0 h-80 w-80 rounded-full bg-secondary/10 blur-[120px]" />
      </div>

      <Sidebar />
      <TopBar />

      <main className="relative mx-auto flex max-w-7xl gap-6 px-4 pb-24 pt-6 lg:pl-72 lg:pb-10 xl:pr-4">
        {/* Colonne centrale */}
        <section className="min-w-0 flex-1 lg:max-w-2xl">
          {/* Recherche desktop dans le layout */}
          <div className="mb-5 hidden lg:block">
            <div className="relative">
              <Search size={17} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                value={query}
                onChange={(e) => runSearch(e.target.value)}
                placeholder="Rechercher des membres…"
                className="w-full rounded-2xl border border-edge bg-card/70 py-3 pl-11 pr-4 text-sm text-white placeholder-slate-500 backdrop-blur transition-all focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              {results && query.trim().length >= 2 && (
                <div className="absolute z-30 mt-2 max-h-80 w-full overflow-y-auto rounded-2xl border border-edge bg-card shadow-card animate-fade-in">
                  {searching ? (
                    <div className="flex justify-center p-4">
                      <Loader2 className="animate-spin text-primary-400" size={20} />
                    </div>
                  ) : results.length === 0 ? (
                    <p className="p-4 text-center text-sm text-slate-500">Aucun membre trouvé.</p>
                  ) : (
                    results.map((p) => (
                      <button
                        key={p.id}
                        onClick={() => {
                          navigate(`/u/${p.username}`)
                          setQuery('')
                          setResults(null)
                        }}
                        className="flex w-full items-center gap-3 border-b border-edge/40 px-4 py-3 text-left transition-colors last:border-0 hover:bg-cardlight"
                      >
                        <Avatar name={p.full_name} src={p.avatar_url} size={38} />
                        <div className="min-w-0">
                          <p className="truncate text-sm font-bold text-white">{p.full_name}</p>
                          <p className="truncate text-xs text-slate-500">@{p.username}</p>
                        </div>
                      </button>
                    ))
                  )}
                </div>
              )}
            </div>
          </div>

          <Outlet />
        </section>

        {/* Colonne droite (desktop) */}
        <aside className="hidden w-80 shrink-0 xl:block">
          <div className="sticky top-6 space-y-5">
            <RightRail />
          </div>
        </aside>
      </main>

      <BottomNav />
    </div>
  )
}

// Le contenu de la colonne droite est injecté par les pages via RightRailSlot.
// Par défaut on affiche un lien Découvrir.
function RightRail() {
  return (
    <div className="rounded-2xl border border-edge bg-card/60 p-5 backdrop-blur">
      <p className="text-sm font-bold text-white">Bienvenue sur NEXORA ✨</p>
      <p className="mt-1.5 text-xs leading-relaxed text-slate-500">
        Partagez vos moments, suivez qui vous voulez et discutez en privé — messages texte et vocal.
      </p>
      <Link
        to="/discover"
        className="mt-3 inline-flex items-center gap-1.5 text-sm font-semibold text-primary-400 transition-colors hover:text-primary-300"
      >
        Découvrir la communauté <ArrowLeft size={14} className="rotate-180" />
      </Link>
    </div>
  )
}

export default MainLayout
