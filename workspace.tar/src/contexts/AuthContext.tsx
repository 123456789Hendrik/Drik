import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react'
import type { Session, User } from '@supabase/supabase-js'
import { supabase } from '../services/supabase'
import { getProfileById } from '../services/authService'
import type { Profile } from '../types'

interface AuthContextValue {
  user: User | null
  profile: Profile | null
  session: Session | null
  loading: boolean
  refreshProfile: () => Promise<void>
  setProfileOptimistic: (p: Profile) => void
}

const AuthContext = createContext<AuthContextValue>({
  user: null,
  profile: null,
  session: null,
  loading: true,
  refreshProfile: async () => {},
  setProfileOptimistic: () => {},
})

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)

  const refreshProfile = useCallback(async () => {
    const uid = session?.user.id
    if (!uid) {
      setProfile(null)
      return
    }
    let p = await getProfileById(uid)
    // Si le trigger DB n'a pas créé le profil, on le crée à la volée
    if (!p) {
      const meta = session.user.user_metadata as Record<string, string> | undefined
      const fallback: Profile = {
        id: uid,
        username: meta?.username ?? 'utilisateur',
        full_name: meta?.full_name ?? 'Utilisateur NEXORA',
        email: session.user.email ?? undefined,
        avatar_url: null,
        bio: '',
        created_at: new Date().toISOString(),
      }
      const { error } = await supabase.from('profiles').upsert(fallback, { onConflict: 'id' })
      if (!error) p = fallback
      else p = fallback
    }
    setProfile(p)
  }, [session])

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session)
      setLoading(false)
    })
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session)
    })
    return () => sub.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    refreshProfile()
  }, [refreshProfile])

  // Présence : mise à jour de last_seen périodique
  useEffect(() => {
    if (!session?.user.id) return
    const update = () =>
      supabase
        .from('profiles')
        .update({ last_seen: new Date().toISOString() })
        .eq('id', session.user.id)
        .catch(() => {})
    update()
    const t = setInterval(update, 60_000)
    return () => clearInterval(t)
  }, [session])

  return (
    <AuthContext.Provider
      value={{
        user: session?.user ?? null,
        profile,
        session,
        loading,
        refreshProfile,
        setProfileOptimistic: setProfile,
      }}
    >
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth(): AuthContextValue {
  return useContext(AuthContext)
}
