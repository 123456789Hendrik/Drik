import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
} from 'react'
import { useAuth } from './AuthContext'
import type { AppNotification } from '../types'
import {
  getNotifications,
  getUnreadCount,
  markAllRead as svcMarkAllRead,
  markOneRead as svcMarkOneRead,
  onNewNotification,
} from '../services/notificationService'

interface NotificationContextValue {
  notifications: AppNotification[]
  unreadCount: number
  refresh: () => Promise<void>
  markAllRead: () => Promise<void>
  markOneRead: (id: string) => Promise<void>
}

const NotificationContext = createContext<NotificationContextValue>({
  notifications: [],
  unreadCount: 0,
  refresh: async () => {},
  markAllRead: async () => {},
  markOneRead: async () => {},
})

export function NotificationProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth()
  const [notifications, setNotifications] = useState<AppNotification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)

  const refresh = useCallback(async () => {
    if (!user) {
      setNotifications([])
      setUnreadCount(0)
      return
    }
    const [list, count] = await Promise.all([getNotifications(user.id), getUnreadCount(user.id)])
    setNotifications(list)
    setUnreadCount(count)
  }, [user])

  useEffect(() => {
    refresh()
    if (!user) return
    const unsub = onNewNotification(user.id, (n) => {
      setNotifications((prev) => [n, ...prev])
      setUnreadCount((c) => c + 1)
    })
    // Rafraîchissement périodique (filet de sécurité si realtime échoue)
    const t = setInterval(refresh, 60_000)
    return () => {
      unsub()
      clearInterval(t)
    }
  }, [user, refresh])

  const markAllRead = useCallback(async () => {
    if (!user) return
    await svcMarkAllRead(user.id)
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })))
    setUnreadCount(0)
  }, [user])

  const markOneRead = useCallback(async (id: string) => {
    await svcMarkOneRead(id)
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, is_read: true } : n))
    )
    setUnreadCount((c) => Math.max(0, c - 1))
  }, [])

  return (
    <NotificationContext.Provider
      value={{ notifications, unreadCount, refresh, markAllRead, markOneRead }}
    >
      {children}
    </NotificationContext.Provider>
  )
}

export function useNotifications(): NotificationContextValue {
  return useContext(NotificationContext)
}
