export interface Profile {
  id: string
  username: string
  full_name: string
  email?: string
  avatar_url: string | null
  bio: string
  created_at: string
  updated_at?: string
  last_seen?: string | null
}

export interface PostImage {
  id: string
  post_id: string
  url: string
  storage_path: string | null
}

export interface Post {
  id: string
  user_id: string
  content: string
  created_at: string
  likes_count?: number
  comments_count?: number
  author?: Profile
  images?: PostImage[]
  liked_by_me?: boolean
}

export interface Comment {
  id: string
  post_id: string
  user_id: string
  content: string
  created_at: string
  author?: Profile
}

export interface Follow {
  id: string
  follower_id: string
  following_id: string
  created_at: string
}

export interface Conversation {
  id: string
  created_at: string
  updated_at?: string
  participants?: string[]
  participant_profiles?: Profile[]
  last_message?: Message | null
  unread_count?: number
}

export type MessageType = 'text' | 'audio'

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  type: MessageType
  audio_path?: string | null
  duration?: number | null
  read_by?: string[]
  created_at: string
  sender?: Profile
}

export type NotificationType = 'follow' | 'like' | 'comment' | 'message'

export interface AppNotification {
  id: string
  user_id: string
  actor_id: string
  type: NotificationType
  post_id?: string | null
  conversation_id?: string | null
  comment_id?: string | null
  is_read: boolean
  created_at: string
  actor?: Profile
}
