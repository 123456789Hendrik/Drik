import { Link } from 'react-router-dom'
import { Heart, MessageCircle, UserPlus, Mail, CheckCheck, X, Bell } from 'lucide-react'
import { useNotifications } from '../contexts/NotificationContext'
import { timeAgo, cn } from '../utils/helpers'
import Avatar from './Avatar'
import { EmptyState } from './ui'
import type { NotificationType } from '../types'

const ICONS: Record<NotificationType, { icon: typeof Heart; color: string; text: string }> = {
  like: { icon: Heart, color: 'text-rose-400 bg-rose-500/15', text: 'a aimé votre publication' },
  comment: { icon: MessageCircle, color: 'text-sky-400 bg-sky-500/15', text: 'a commenté votre publication' },
  follow: { icon: UserPlus, color: 'text-primary-400 bg-primary/15', text: 's’est abonné(e) à vous' },
  message: { icon: Mail, color: 'text-emerald-400 bg-emerald-500/15', text: 'vous a envoyé un message' },
}

export default function NotificationPanel({ onClose }: { onClose?: () => void }) {
  const { notifications, unreadCount, markAllRead, markOneRead } = useNotifications()

  return (
    <div className="flex max-h-[70vh] flex-col overflow-hidden rounded-2xl border border-edge bg-card shadow-card">
      <div className="flex items-center justify-between border-b border-edge px-4 py-3">
        <div className="flex items-center gap-2 font-bold text-white">
          <Bell size={16} className="text-primary-400" /> Notifications
          {unreadCount > 0 && (
            <span className="rounded-full bg-primary/20 px-2 py-0.5 text-xs text-primary-300">
              {unreadCount} non lue{unreadCount > 1 ? 's' : ''}
            </span>
          )}
        </div>
        <div className="flex items-center gap-1">
          {unreadCount > 0 && (
            <button
              onClick={markAllRead}
              className="flex items-center gap-1 rounded-lg px-2 py-1 text-xs font-medium text-primary-300 transition-colors hover:bg-primary/10"
            >
              <CheckCheck size={14} /> Tout marquer lu
            </button>
          )}
          {onClose && (
            <button onClick={onClose} className="rounded-lg p-1.5 text-slate-500 hover:bg-cardlight hover:text-white">
              <X size={15} />
            </button>
          )}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto">
        {notifications.length === 0 ? (
          <EmptyState icon={<Bell size={24} />} title="Aucune notification" subtitle="Les activités apparaîtront ici." />
        ) : (
          notifications.map((n) => {
            const meta = ICONS[n.type]
            const Icon = meta.icon
            const to =
              n.type === 'follow'
                ? `/u/${n.actor?.username ?? ''}`
                : n.type === 'message'
                ? `/messages/${n.conversation_id ?? ''}`
                : n.post_id
                ? `/?post=${n.post_id}`
                : '/'
            return (
              <Link
                key={n.id}
                to={to}
                onClick={() => !n.is_read && markOneRead(n.id)}
                className={cn(
                  'flex items-start gap-3 border-b border-edge/50 px-4 py-3 transition-colors hover:bg-cardlight',
                  !n.is_read && 'bg-primary/5'
                )}
              >
                <div className="relative">
                  <Avatar name={n.actor?.full_name ?? '?'} src={n.actor?.avatar_url} size={38} />
                  <span
                    className={cn(
                      'absolute -bottom-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full ring-2 ring-card',
                      meta.color
                    )}
                  >
                    <Icon size={11} />
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-slate-200">
                    <span className="font-bold text-white">{n.actor?.full_name}</span>{' '}
                    <span className="text-slate-400">{meta.text}</span>
                  </p>
                  <p className="mt-0.5 text-xs text-slate-500">{timeAgo(n.created_at)}</p>
                </div>
                {!n.is_read && <span className="mt-2 h-2 w-2 shrink-0 rounded-full bg-primary" />}
              </Link>
            )
          })
        )}
      </div>
    </div>
  )
}
