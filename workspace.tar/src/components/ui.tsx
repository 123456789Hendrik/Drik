import { cn } from '../utils/helpers'

export function Button({
  className,
  variant = 'primary',
  size = 'md',
  ...props
}: React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'outline'
  size?: 'sm' | 'md' | 'lg'
}) {
  return (
    <button
      className={cn(
        'inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/50 disabled:cursor-not-allowed disabled:opacity-50 active:scale-[0.97]',
        size === 'sm' && 'px-3 py-1.5 text-sm',
        size === 'md' && 'px-4 py-2.5 text-sm',
        size === 'lg' && 'px-6 py-3 text-base',
        variant === 'primary' &&
          'bg-gradient-to-r from-primary to-secondary text-white shadow-glow hover:brightness-110',
        variant === 'secondary' && 'bg-cardlight text-white ring-1 ring-edge hover:bg-edge',
        variant === 'ghost' && 'text-slate-300 hover:bg-cardlight hover:text-white',
        variant === 'outline' &&
          'border border-primary/60 text-primary-300 hover:bg-primary/10 hover:text-white',
        variant === 'danger' && 'bg-rose-600/90 text-white hover:bg-rose-600',
        className
      )}
      {...props}
    />
  )
}

export function Input({
  className,
  label,
  error,
  ...props
}: React.InputHTMLAttributes<HTMLInputElement> & { label?: string; error?: string }) {
  return (
    <label className="block">
      {label && (
        <span className="mb-1.5 block text-sm font-medium text-slate-300">{label}</span>
      )}
      <input
        className={cn(
          'w-full rounded-xl border bg-night/60 px-4 py-2.5 text-sm text-white placeholder-slate-500 transition-all focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30',
          error ? 'border-rose-500/70' : 'border-edge',
          className
        )}
        {...props}
      />
      {error && <span className="mt-1 block text-xs text-rose-400">{error}</span>}
    </label>
  )
}

export function Textarea({
  className,
  label,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label?: string }) {
  return (
    <label className="block">
      {label && (
        <span className="mb-1.5 block text-sm font-medium text-slate-300">{label}</span>
      )}
      <textarea
        className={cn(
          'w-full resize-none rounded-xl border border-edge bg-night/60 px-4 py-2.5 text-sm text-white placeholder-slate-500 transition-all focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30',
          className
        )}
        {...props}
      />
    </label>
  )
}

export function Card({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <div className={cn('rounded-2xl border border-edge bg-card shadow-card', className)}>
      {children}
    </div>
  )
}

export function Spinner({ className }: { className?: string }) {
  return (
    <div
      className={cn(
        'h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent',
        className
      )}
    />
  )
}

export function EmptyState({
  icon,
  title,
  subtitle,
}: {
  icon: React.ReactNode
  title: string
  subtitle?: string
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-14 text-center">
      <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-cardlight text-primary-400 ring-1 ring-edge">
        {icon}
      </div>
      <p className="font-semibold text-slate-200">{title}</p>
      {subtitle && <p className="max-w-xs text-sm text-slate-500">{subtitle}</p>}
    </div>
  )
}
