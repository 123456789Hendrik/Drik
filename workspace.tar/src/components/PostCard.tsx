import { useCallback, useEffect, useRef, useState } from 'react'
import { Link } from 'react-router-dom'
import { Heart, MessageCircle, Trash2, ImagePlus, X, Send, Loader2 } from 'lucide-react'
import type { Post, Comment } from '../types'
import { useAuth } from '../contexts/AuthContext'
import Avatar from './Avatar'
import { timeAgo, cn } from '../utils/helpers'
import { addComment, deleteComment, deletePost, getComments, toggleLike } from '../services/postService'
import { createNotification } from '../services/notificationService'

interface Props {
  post: Post
  onChanged?: () => void
  highlight?: boolean
}

export default function PostCard({ post, onChanged, highlight }: Props) {
  const { user, profile } = useAuth()
  const [liked, setLiked] = useState(post.liked_by_me ?? false)
  const [likesCount, setLikesCount] = useState(post.likes_count ?? 0)
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState<Comment[] | null>(null)
  const [newComment, setNewComment] = useState('')
  const [sending, setSending] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [lightbox, setLightbox] = useState<string | null>(null)
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setLiked(post.liked_by_me ?? false)
    setLikesCount(post.likes_count ?? 0)
  }, [post])

  useEffect(() => {
    if (highlight && cardRef.current) {
      cardRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' })
    }
  }, [highlight])

  const loadComments = useCallback(async () => {
    const c = await getComments(post.id)
    setComments(c)
  }, [post.id])

  const handleLike = async () => {
    if (!user) return
    const optimistic = !liked
    setLiked(optimistic)
    setLikesCount((c) => c + (optimistic ? 1 : -1))
    const { error } = await toggleLike(post.id, user.id)
    if (error) {
      setLiked(!optimistic)
      setLikesCount((c) => c + (optimistic ? -1 : 1))
      return
    }
    if (optimistic && post.author && post.author.id !== user.id) {
      createNotification({ user_id: post.author.id, actor_id: user.id, type: 'like', post_id: post.id })
    }
  }

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !newComment.trim()) return
    setSending(true)
    const { error } = await addComment(post.id, user.id, newComment)
    setSending(false)
    if (!error) {
      setNewComment('')
      await loadComments()
      if (post.author && post.author.id !== user.id) {
        createNotification({ user_id: post.author.id, actor_id: user.id, type: 'comment', post_id: post.id })
      }
      onChanged?.()
    }
  }

  const handleDelete = async () => {
    if (!user || !profile) return
    if (!window.confirm('Supprimer cette publication ? Cette action est irréversible.')) return
    setDeleting(true)
    const { error } = await deletePost(post.id, user.id)
    setDeleting(false)
    if (!error) onChanged?.()
  }

  const handleDeleteComment = async (id: string) => {
    if (!user) return
    await deleteComment(id, user.id)
    await loadComments()
  }

  const isOwner = user?.id === post.user_id
  const gridCols =
    post.images && post.images.length === 1
      ? 'grid-cols-1'
      : post.images && post.images.length === 3
      ? 'grid-cols-3'
      : 'grid-cols-2'

  return (
    <>
      <div
        ref={cardRef}
        className={cn(
          'animate-fade-up overflow-hidden rounded-2xl border bg-card shadow-card transition-all duration-300',
          highlight ? 'border-primary ring-2 ring-primary/40' : 'border-edge hover:border-primary/30'
        )}
      >
        {/* En-tête auteur */}
        <div className="flex items-center gap-3 p-4 pb-3">
          <Link to={`/u/${post.author?.username}`}>
            <Avatar name={post.author?.full_name ?? '?'} src={post.author?.avatar_url} size={44} />
          </Link>
          <div className="min-w-0 flex-1">
            <Link to={`/u/${post.author?.username}`} className="block truncate font-bold text-white hover:underline">
              {post.author?.full_name}
            </Link>
            <p className="truncate text-xs text-slate-500">
              @{post.author?.username} · {timeAgo(post.created_at)}
            </p>
          </div>
          {isOwner && (
            <button
              onClick={handleDelete}
              disabled={deleting}
              title="Supprimer la publication"
              className="rounded-xl p-2 text-slate-500 transition-colors hover:bg-rose-500/15 hover:text-rose-400"
            >
              {deleting ? <Loader2 size={17} className="animate-spin" /> : <Trash2 size={17} />}
            </button>
          )}
        </div>

        {/* Texte */}
        {post.content && (
          <p className="whitespace-pre-wrap break-words px-4 pb-3 text-[15px] leading-relaxed text-slate-200">
            {post.content}
          </p>
        )}

        {/* Images */}
        {post.images && post.images.length > 0 && (
          <div className={cn('grid gap-1 px-1 pb-2', gridCols)}>
            {post.images.slice(0, 4).map((img, i) => (
              <button
                key={img.id}
                onClick={() => setLightbox(img.url)}
                className={cn(
                  'group relative overflow-hidden rounded-xl',
                  post.images!.length === 3 && i === 0 && 'col-span-3 aspect-video',
                  post.images!.length === 3 && i > 0 && 'aspect-square',
                  post.images!.length !== 3 && (post.images!.length === 1 ? 'aspect-auto max-h-96' : 'aspect-square')
                )}
              >
                <img
                  src={img.url}
                  alt=""
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </button>
            ))}
          </div>
        )}

        {/* Actions */}
        <div className="flex items-center gap-1 border-t border-edge/60 px-2 py-1.5">
          <button
            onClick={handleLike}
            className={cn(
              'flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition-all',
              liked
                ? 'text-rose-400 hover:bg-rose-500/10'
                : 'text-slate-400 hover:bg-cardlight hover:text-rose-300'
            )}
          >
            <Heart size={18} fill={liked ? 'currentColor' : 'none'} className={liked ? 'animate-pop' : ''} />
            {likesCount}
          </button>
          <button
            onClick={() => {
              setShowComments((v) => !v)
              if (!comments) loadComments()
            }}
            className={cn(
              'flex items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition-all',
              showComments ? 'text-sky-400 bg-sky-500/10' : 'text-slate-400 hover:bg-cardlight hover:text-sky-300'
            )}
          >
            <MessageCircle size={18} />
            {post.comments_count ?? comments?.length ?? 0}
          </button>
        </div>

        {/* Commentaires */}
        {showComments && (
          <div className="border-t border-edge/60 bg-night/30 p-4">
            {comments === null ? (
              <div className="flex justify-center py-4">
                <Loader2 className="animate-spin text-primary-400" size={22} />
              </div>
            ) : comments.length === 0 ? (
              <p className="py-2 text-center text-sm text-slate-500">
                <MessageCircle size={16} className="mr-1 inline" /> Aucun commentaire pour l'instant.
              </p>
            ) : (
              <div className="mb-3 flex max-h-72 flex-col gap-3 overflow-y-auto pr-1">
                {comments.map((c) => (
                  <div key={c.id} className="flex gap-2.5 animate-fade-in">
                    <Link to={`/u/${c.author?.username}`}>
                      <Avatar name={c.author?.full_name ?? '?'} src={c.author?.avatar_url} size={32} />
                    </Link>
                    <div className="min-w-0 flex-1 rounded-2xl rounded-tl-sm bg-cardlight px-3.5 py-2.5 ring-1 ring-edge/60">
                      <div className="flex items-baseline gap-2">
                        <Link
                          to={`/u/${c.author?.username}`}
                          className="text-sm font-bold text-white hover:underline"
                        >
                          {c.author?.full_name}
                        </Link>
                        <span className="text-[11px] text-slate-500">{timeAgo(c.created_at)}</span>
                        {user?.id === c.user_id && (
                          <button
                            onClick={() => handleDeleteComment(c.id)}
                            className="ml-auto text-slate-600 transition-colors hover:text-rose-400"
                            title="Supprimer"
                          >
                            <X size={13} />
                          </button>
                        )}
                      </div>
                      <p className="mt-0.5 whitespace-pre-wrap break-words text-sm text-slate-300">{c.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <form onSubmit={handleComment} className="flex items-center gap-2">
              <Avatar name={profile?.full_name ?? '?'} src={profile?.avatar_url} size={34} />
              <input
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Écrire un commentaire…"
                maxLength={1000}
                className="flex-1 rounded-full border border-edge bg-night/60 px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                type="submit"
                disabled={sending || !newComment.trim()}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white shadow-glow transition-all hover:brightness-110 disabled:opacity-40"
              >
                {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
              </button>
            </form>
          </div>
        )}
      </div>

      {/* Lightbox image */}
      {lightbox && (
        <div
          className="fixed inset-0 z-[100] flex animate-fade-in items-center justify-center bg-black/90 p-4 backdrop-blur-sm"
          onClick={() => setLightbox(null)}
        >
          <button className="absolute right-4 top-4 rounded-full bg-white/10 p-2 text-white hover:bg-white/20">
            <X size={22} />
          </button>
          <img src={lightbox} alt="" className="max-h-full max-w-full rounded-xl object-contain" />
        </div>
      )}
    </>
  )
}

export function PostComposer({ onCreated }: { onCreated: () => void }) {
  const { user, profile } = useAuth()
  const [content, setContent] = useState('')
  const [files, setFiles] = useState<File[]>([])
  const [previews, setPreviews] = useState<string[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFiles = (list: FileList | null) => {
    if (!list) return
    const arr = Array.from(list)
    if (files.length + arr.length > 4) {
      setError('Maximum 4 images par publication.')
      return
    }
    const urls = arr.map((f) => URL.createObjectURL(f))
    setFiles((prev) => [...prev, ...arr])
    setPreviews((prev) => [...prev, ...urls])
    setError(null)
  }

  const removeFile = (i: number) => {
    URL.revokeObjectURL(previews[i]!)
    setFiles((prev) => prev.filter((_, idx) => idx !== i))
    setPreviews((prev) => prev.filter((_, idx) => idx !== i))
  }

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return
    if (!content.trim() && files.length === 0) {
      setError('Votre publication est vide.')
      return
    }
    setSubmitting(true)
    setError(null)
    // import dynamique pour éviter cycle
    const { createPost } = await import('../services/postService')
    const { error } = await createPost(user.id, content, files)
    setSubmitting(false)
    if (error) {
      setError(error)
      return
    }
    setContent('')
    previews.forEach((p) => URL.revokeObjectURL(p))
    setFiles([])
    setPreviews([])
    onCreated()
  }

  return (
    <form
      onSubmit={submit}
      className="overflow-hidden rounded-2xl border border-edge bg-card shadow-card transition-colors focus-within:border-primary/40"
    >
      <div className="flex gap-3 p-4">
        <Avatar name={profile?.full_name ?? '?'} src={profile?.avatar_url} size={44} />
        <textarea
          value={content}
          onChange={(e) => setContent(e.target.value)}
          placeholder="Quoi de neuf ? Partagez le moment…"
          rows={2}
          maxLength={2000}
          className="flex-1 resize-none bg-transparent text-[15px] text-white placeholder-slate-500 focus:outline-none"
        />
      </div>

      {previews.length > 0 && (
        <div className="grid grid-cols-4 gap-2 px-4 pb-2">
          {previews.map((src, i) => (
            <div key={src} className="group relative aspect-square overflow-hidden rounded-xl">
              <img src={src} alt="" className="h-full w-full object-cover" />
              <button
                type="button"
                onClick={() => removeFile(i)}
                className="absolute right-1 top-1 rounded-full bg-black/70 p-1 text-white opacity-0 transition-opacity group-hover:opacity-100"
              >
                <X size={13} />
              </button>
            </div>
          ))}
        </div>
      )}

      {error && <p className="px-4 pb-2 text-sm text-rose-400">{error}</p>}

      <div className="flex items-center justify-between border-t border-edge/60 px-4 py-2.5">
        <button
          type="button"
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-medium text-primary-300 transition-colors hover:bg-primary/10"
        >
          <ImagePlus size={18} /> Photos
          <span className="text-xs text-slate-600">({files.length}/4)</span>
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="image/jpeg,image/png,image/webp,image/gif"
          multiple
          hidden
          onChange={(e) => handleFiles(e.target.files)}
        />
        <button
          type="submit"
          disabled={submitting}
          className="flex items-center gap-2 rounded-full bg-gradient-to-r from-primary to-secondary px-5 py-2 text-sm font-bold text-white shadow-glow transition-all hover:brightness-110 active:scale-95 disabled:opacity-50"
        >
          {submitting ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
          Publier
        </button>
      </div>
    </form>
  )
}
