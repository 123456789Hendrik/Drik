import { useEffect, useRef, useState } from 'react'
import { Mic, Square, Play, Pause, Trash2, Send, Loader2 } from 'lucide-react'
import { formatDuration, cn } from '../utils/helpers'

interface Props {
  onSend: (blob: Blob, durationSec: number) => Promise<void>
  disabled?: boolean
}

/** Enregistreur de messages vocaux basé sur MediaRecorder API. */
export default function VoiceRecorder({ onSend, disabled }: Props) {
  const [state, setState] = useState<'idle' | 'recording' | 'preview'>('idle')
  const [seconds, setSeconds] = useState(0)
  const [blob, setBlob] = useState<Blob | null>(null)
  const [previewUrl, setPreviewUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [sending, setSending] = useState(false)
  const recorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const timerRef = useRef<number | null>(null)
  const audioRef = useRef<HTMLAudioElement>(null)

  const stopTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
  }

  const cleanup = () => {
    stopTimer()
    recorderRef.current?.stream.getTracks().forEach((t) => t.stop())
    if (previewUrl) URL.revokeObjectURL(previewUrl)
    setBlob(null)
    setPreviewUrl(null)
    setSeconds(0)
    setState('idle')
  }

  const start = async () => {
    setError(null)
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
        ? 'audio/webm;codecs=opus'
        : MediaRecorder.isTypeSupported('audio/webm')
        ? 'audio/webm'
        : MediaRecorder.isTypeSupported('audio/mp4')
        ? 'audio/mp4'
        : ''
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined)
      chunksRef.current = []
      rec.ondataavailable = (e) => e.data.size > 0 && chunksRef.current.push(e.data)
      rec.onstop = () => {
        const b = new Blob(chunksRef.current, { type: rec.mimeType || 'audio/webm' })
        stream.getTracks().forEach((t) => t.stop())
        if (b.size < 1000) {
          setError('Enregistrement trop court.')
          cleanup()
          return
        }
        setBlob(b)
        setPreviewUrl(URL.createObjectURL(b))
        setState('preview')
      }
      recorderRef.current = rec
      rec.start()
      setSeconds(0)
      setState('recording')
      timerRef.current = window.setInterval(() => {
        setSeconds((s) => {
          if (s >= 300) {
            recorderRef.current?.stop()
            return 300
          }
          return s + 1
        })
      }, 1000)
    } catch (err) {
      const e = err as DOMException
      if (e.name === 'NotAllowedError')
        setError('Accès au microphone refusé. Autorisez le micro dans les réglages du navigateur.')
      else if (e.name === 'NotFoundError') setError('Aucun microphone détecté.')
      else setError("Impossible de démarrer l'enregistrement.")
      setState('idle')
    }
  }

  const stop = () => {
    stopTimer()
    recorderRef.current?.stop()
  }

  const send = async () => {
    if (!blob) return
    setSending(true)
    await onSend(blob, seconds)
    setSending(false)
    cleanup()
  }

  const togglePlay = () => {
    if (!audioRef.current) return
    if (audioRef.current.paused) audioRef.current.play()
    else audioRef.current.pause()
  }

  if (state === 'idle') {
    return (
      <div className="flex flex-col items-end gap-1">
        {error && <p className="max-w-56 text-right text-xs text-rose-400">{error}</p>}
        <button
          onClick={start}
          disabled={disabled}
          title="Message vocal"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-edge bg-cardlight text-primary-300 transition-all hover:border-primary/60 hover:text-white active:scale-90 disabled:opacity-40"
        >
          <Mic size={18} />
        </button>
      </div>
    )
  }

  if (state === 'recording') {
    return (
      <div className="flex flex-1 items-center gap-2 rounded-full border border-rose-500/50 bg-rose-500/10 px-4 py-2 animate-fade-in">
        <span className="relative flex h-3 w-3">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-500 opacity-75" />
          <span className="relative inline-flex h-3 w-3 rounded-full bg-rose-500" />
        </span>
        <span className="font-mono text-sm font-bold text-rose-300">{formatDuration(seconds)}</span>
        <div className="flex flex-1 items-center gap-[3px] overflow-hidden">
          {Array.from({ length: 18 }).map((_, i) => (
            <span
              key={i}
              className="w-1 rounded-full bg-rose-400/70"
              style={{
                height: `${6 + Math.abs(Math.sin(Date.now() / 200 + i)) * 14}px`,
                animation: `pulseSoft ${0.5 + (i % 5) * 0.15}s ease-in-out infinite`,
              }}
            />
          ))}
        </div>
        <button
          onClick={stop}
          title="Arrêter"
          className="flex h-9 w-9 items-center justify-center rounded-full bg-rose-500 text-white transition-transform hover:scale-105 active:scale-90"
        >
          <Square size={15} fill="currentColor" />
        </button>
        <button
          onClick={cleanup}
          title="Annuler"
          className="rounded-full p-2 text-slate-400 hover:bg-cardlight hover:text-white"
        >
          <Trash2 size={16} />
        </button>
      </div>
    )
  }

  // Preview
  return (
    <div className="flex flex-1 items-center gap-2 rounded-full border border-primary/40 bg-primary/10 px-3 py-2 animate-fade-in">
      {previewUrl && <audio ref={audioRef} src={previewUrl} className="hidden" />}
      <button
        onClick={togglePlay}
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white"
      >
        <Play size={15} id="play-icon" />
      </button>
      <div className="flex-1">
        <p className="text-xs font-semibold text-primary-200">Préécoute · {formatDuration(seconds)}</p>
        <div className="mt-1 flex items-center gap-[3px]">
          {Array.from({ length: 24 }).map((_, i) => (
            <span
              key={i}
              className={cn('w-1 rounded-full bg-primary-400/60')}
              style={{ height: `${4 + ((i * 7) % 12)}px` }}
            />
          ))}
        </div>
      </div>
      <button
        onClick={cleanup}
        title="Jeter l'enregistrement"
        className="rounded-full p-2 text-slate-400 transition-colors hover:bg-rose-500/20 hover:text-rose-400"
      >
        <Trash2 size={16} />
      </button>
      <button
        onClick={send}
        disabled={sending}
        title="Envoyer le message vocal"
        className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white shadow-glow transition-transform hover:scale-105 active:scale-90 disabled:opacity-50"
      >
        {sending ? <Loader2 size={15} className="animate-spin" /> : <Send size={15} />}
      </button>
    </div>
  )
}
