import { useState } from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import {
  Home,
  Compass,
  Bell,
  MessageCircle,
  User,
  LogOut,
  Sparkles,
  Search,
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { useNotifications } from '../contexts/NotificationContext'
import { signOut } from '../services/authService'
import Avatar from './Avatar'
import NotificationPanel from './NotificationPanel'
import { cn } from '../utils/helpers'

const NAV = [
  { to: '/', label: 'Accueil', icon: Home },
  { to: '/discover', label: 'Découvrir', icon: Compass },
  { to: '/notifications', label: 'Notifications', icon: Bell, badge: true },
  { to: '/messages', label: 'Messages', icon: MessageCircle },
  { to: '/profile', label: 'Profil', icon: User },
]

export function Logo({ compact }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-secondary text-white shadow-glow">
        <Sparkles size={18} />
      </span>
      {!compact && (
        <span className="bg-gradient-to-r from-primary-400 to-secondary-400 bg-clip-text text-xl font-extrabold tracking-tight text-transparent">
          NEXORA
        </span>
      )}
    </Link>
  )
}

export function Sidebar() {
  const { profile } = useAuth()
  const { unreadCount } = useNotifications()
  const navigate = useNavigate()
  const location = useLocation()
  const [showNotifs, setShowNotifs] = useState(false)

  const handleLogout = async () => {
    await signOut()
    navigate('/login')
  }

  return (
    <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-edge bg-card/60 px-4 py-6 backdrop-blur-xl lg:flex">
      <div className="px-2">
        <Logo />
      </div>

      <nav className="mt-8 flex flex-1 flex-col gap-1.5">
        {NAV.map((item) => (
          <button
            key={item.to}
            onClick={() => {
              if (item.to === '/notifications') {
                setShowNotifs((v) => !v)
                navigate('/notifications')
              } else {
                setShowNotifs(false)
                navigate(item.to)
              }
            }}
            className={cn(
              'group relative flex items-center gap-3.5 rounded-xl px-4 py-3 text-sm font-semibold transition-all duration-200',
              location.pathname === item.to
                ? 'bg-gradient-to-r from-primary/25 to-secondary/15 text-white ring-1 ring-primary/40'
                : 'text-slate-400 hover:bg-cardlight hover:text-white hover:translate-x-1'
            )}
          >
            <item.icon size={20} className={cn('transition-colors', location.pathname === item.to ? 'text-primary-400' : '')} />
            {item.label}
            {item.badge && unreadCount > 0 && (
              <span className="ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary px-1.5 text-xs font-bold text-white">
                {unreadCount > 9 ? '9+' : unreadCount}
              </span>
            )}
          </button>
        ))}
      </nav>

      {profile && (
        <Link
          to={`/u/${profile.username}`}
          className="mt-4 flex items-center gap-3 rounded-xl border border-edge bg-night/50 p-3 transition-all hover:border-primary/50 hover:bg-cardlight"
        >
          <Avatar name={profile.full_name} src={profile.avatar_url} size={40} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-bold text-white">{profile.full_name}</p>
            <p className="truncate text-xs text-slate-500">@{profile.username}</p>
          </div>
          <button
            onClick={(e) => {
              e.preventDefault()
              handleLogout()
            }}
            title="Se déconnecter"
            className="rounded-lg p-2 text-slate-500 transition-colors hover:bg-rose-500/15 hover:text-rose-400"
          >
            <LogOut size={17} />
          </button>
        </Link>
      )}

      {showNotifs && (
        <div className="absolute bottom-24 left-4 right-4 max-h-96 overflow-hidden rounded-2xl">
          <NotificationPanel onClose={() => setShowNotifs(false)} />
        </div>
      )}
    </aside>
  )
}

export function TopBar() {
  const { profile } = useAuth()
  const { unreadCount } = useNotifications()
  const navigate = useNavigate()
  const [showNotifs, setShowNotifs] = useState(false)

  return (
    <header className="sticky top-0 z-40 flex items-center gap-3 border-b border-edge bg-night/80 px-4 py-3 backdrop-blur-xl lg:hidden">
      <Logo />
      <button
        onClick={() => navigate('/discover')}
        className="ml-auto flex items-center gap-2 rounded-xl border border-edge bg-card px-3 py-2 text-sm text-slate-400 transition-colors hover:border-primary/40"
      >
        <Search size={16} />
        Rechercher
      </button>
      <div className="relative">
        <button
          onClick={() => setShowNotifs((v) => !v)}
          className="relative rounded-xl border border-edge bg-card p-2 text-slate-300 transition-colors hover:border-primary/40 hover:text-white"
        >
          <Bell size={18} />
          {unreadCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-4 min-w-4 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary px-1 text-[10px] font-bold text-white">
              {unreadCount > 9 ? '9+' : unreadCount}
            </span>
          )}
        </button>
        {showNotifs && (
          <div className="absolute right-0 top-12 z-50 w-80 max-w-[calc(100vw-2rem)] overflow-hidden rounded-2xl">
            <NotificationPanel onClose={() => setShowNotifs(false)} />
          </div>
        )}
      </div>
      {profile && <Avatar name={profile.full_name} src={profile.avatar_url} size={36} />}
    </header>
  )
}

export function BottomNav() {
  const location = useLocation()
  const pathname = location.pathname
  const { unreadCount } = useNotifications()
  return (
    <nav className="fixed inset-x-0 bottom-0 z-40 flex items-stretch justify-around border-t border-edge bg-card/90 pb-[env(safe-area-inset-bottom)] backdrop-blur-xl lg:hidden">
      {NAV.map((item) => {
        const active = pathname === item.to || (item.to !== '/' && pathname.startsWith(item.to))
        return (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              'relative flex flex-1 flex-col items-center gap-0.5 py-2.5 text-[11px] font-medium transition-colors',
              active ? 'text-primary-400' : 'text-slate-500 hover:text-slate-300'
            )}
          >
            <span className="relative">
              <item.icon size={22} strokeWidth={active ? 2.4 : 2} />
              {item.badge && unreadCount > 0 && (
                <span className="absolute -right-2 -top-1.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary px-1 text-[9px] font-bold text-white">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </span>
            {item.label}
            {active && (
              <span className="absolute inset-x-6 top-0 h-0.5 rounded-full bg-gradient-to-r from-primary to-secondary" />
            )}
          </Link>
        )
      })}
    </nav>
  )
}
