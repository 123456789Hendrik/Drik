import { cn, initials, avatarColor } from '../utils/helpers'

interface Props {
  name: string
  src?: string | null
  size?: number
  className?: string
  online?: boolean
  link?: boolean
}

export default function Avatar({ name, src, size = 44, className, online, link }: Props) {
  const style = { width: size, height: size }
  const inner = src ? (
    <img
      src={src}
      alt={name}
      className="h-full w-full rounded-full object-cover"
      loading="lazy"
    />
  ) : (
    <div
      className="flex h-full w-full items-center justify-center rounded-full font-bold text-white"
      style={{ ...style, background: `linear-gradient(135deg, ${avatarColor(name)}, ${avatarColor(name + 'x')})`, fontSize: size * 0.38 }}
    >
      {initials(name) || '?'}
    </div>
  )

  const content = (
    <div className={cn('relative shrink-0', className)} style={style}>
      {src ? (
        <div
          className="h-full w-full overflow-hidden rounded-full ring-2 ring-edge"
          style={{ background: `linear-gradient(135deg, ${avatarColor(name)}, ${avatarColor(name + 'x')})` }}
        >
          {inner}
        </div>
      ) : (
        inner
      )}
      {online !== undefined && (
        <span
          className={cn(
            'absolute bottom-0 right-0 block rounded-full border-2 border-night',
            online ? 'bg-emerald-400' : 'bg-slate-500'
          )}
          style={{ width: Math.max(10, size * 0.26), height: Math.max(10, size * 0.26) }}
        />
      )}
    </div>
  )

  if (link === false) return content
  return content
}
