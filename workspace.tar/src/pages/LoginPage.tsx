import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Mail, Lock, Eye, EyeOff, Loader2, Sparkles, AlertCircle } from 'lucide-react'
import { signIn, resetPassword } from '../services/authService'
import { isSupabaseConfigured } from '../services/supabase'
import { validators } from '../utils/helpers'
import { Button, Input } from '../components/ui'

export default function LoginPage() {
  const navigate = useNavigate()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [resetMsg, setResetMsg] = useState<string | null>(null)
  const [resetEmail, setResetEmail] = useState('')
  const [showReset, setShowReset] = useState(false)

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!isSupabaseConfigured) {
      setError('Supabase non configuré. Renseignez le fichier .env (voir README).')
      return
    }
    if (!validators.email(email)) {
      setError('Adresse email invalide.')
      return
    }
    if (!password) {
      setError('Mot de passe requis.')
      return
    }
    setLoading(true)
    const { error } = await signIn(email, password)
    setLoading(false)
    if (error) {
      setError(error)
      return
    }
    navigate('/')
  }

  const doReset = async (e: React.FormEvent) => {
    e.preventDefault()
    setResetMsg(null)
    if (!validators.email(resetEmail)) {
      setResetMsg('⚠️ Adresse email invalide.')
      return
    }
    const { error } = await resetPassword(resetEmail)
    setResetMsg(
      error ? '⚠️ ' + error : '✅ Un email de réinitialisation vous a été envoyé. Vérifiez votre boîte.'
    )
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-night px-4 py-10 text-slate-100">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 left-1/3 h-[420px] w-[420px] rounded-full bg-primary/20 blur-[140px]" />
        <div className="absolute bottom-0 right-1/4 h-[380px] w-[380px] rounded-full bg-secondary/20 blur-[140px]" />
      </div>

      <div className="relative w-full max-w-md animate-fade-up">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-white shadow-glow">
            <Sparkles size={30} />
          </span>
          <h1 className="bg-gradient-to-r from-primary-400 via-violet-300 to-secondary-400 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent">
            NEXORA
          </h1>
          <p className="text-sm text-slate-500">Le réseau social nouvelle génération.</p>
        </div>

        <div className="rounded-3xl border border-edge bg-card/80 p-7 shadow-card backdrop-blur-xl">
          <h2 className="text-xl font-bold text-white">Connexion</h2>
          <p className="mt-1 text-sm text-slate-500">Ravi de vous revoir 👋</p>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-300 animate-fade-in">
              <AlertCircle size={17} className="mt-0.5 shrink-0" /> {error}
            </div>
          )}

          <form onSubmit={submit} className="mt-5 space-y-4">
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                type="email"
                placeholder="adresse@email.com"
                label="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-11"
                autoComplete="email"
              />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                type={showPass ? 'text' : 'password'}
                placeholder="••••••••"
                label="Mot de passe"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-11 pr-11"
                autoComplete="current-password"
              />
              <button
                type="button"
                onClick={() => setShowPass((v) => !v)}
                className="absolute right-3.5 top-[34px] text-slate-500 hover:text-slate-300"
              >
                {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>

            <button
              type="button"
              onClick={() => {
                setShowReset((v) => !v)
                setResetEmail(email)
              }}
              className="text-xs font-medium text-primary-400 transition-colors hover:text-primary-300"
            >
              Mot de passe oublié ?
            </button>

            <Button type="submit" disabled={loading} className="w-full" size="lg">
              {loading ? <Loader2 size={18} className="animate-spin" /> : 'Se connecter'}
            </Button>
          </form>

          {showReset && (
            <form onSubmit={doReset} className="mt-4 space-y-3 rounded-2xl border border-edge bg-night/50 p-4 animate-fade-in">
              <p className="text-sm font-semibold text-slate-300">Réinitialiser le mot de passe</p>
              <Input
                type="email"
                placeholder="Votre adresse email"
                value={resetEmail}
                onChange={(e) => setResetEmail(e.target.value)}
              />
              {resetMsg && <p className="text-xs text-slate-400">{resetMsg}</p>}
              <Button type="submit" variant="secondary" size="sm" className="w-full">
                Envoyer le lien de réinitialisation
              </Button>
            </form>
          )}

          <p className="mt-6 text-center text-sm text-slate-500">
            Pas encore de compte ?{' '}
            <Link to="/register" className="font-bold text-primary-400 transition-colors hover:text-primary-300">
              Créer un compte
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
