import { useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Camera, Loader2, LogOut, ShieldCheck, KeyRound, AlertCircle, CheckCircle2 } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { updateProfile, updatePassword, signOut } from '../services/authService'
import { validators } from '../utils/helpers'
import Avatar from '../components/Avatar'
import { Button, Card, Input, Textarea } from '../components/ui'

const MAX_AVATAR_SIZE = 2 * 1024 * 1024
const AVATAR_TYPES = ['image/jpeg', 'image/png', 'image/webp']

export default function SettingsPage() {
  const { user, profile, refreshProfile } = useAuth()
  const navigate = useNavigate()
  const [fullName, setFullName] = useState(profile?.full_name ?? '')
  const [username, setUsername] = useState(profile?.username ?? '')
  const [bio, setBio] = useState(profile?.bio ?? '')
  const [avatarFile, setAvatarFile] = useState<File | null>(null)
  const [avatarPreview, setAvatarPreview] = useState<string | null>(null)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ ok: boolean; text: string } | null>(null)

  // Mot de passe
  const [newPass, setNewPass] = useState('')
  const [confirmPass, setConfirmPass] = useState('')
  const [passMsg, setPassMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const [changingPass, setChangingPass] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  if (!profile || !user) return null

  const pickAvatar = (f: File | null) => {
    setMessage(null)
    if (!f) return
    if (!AVATAR_TYPES.includes(f.type)) {
      setMessage({ ok: false, text: 'Format non supporté : utilisez JPG, PNG ou WEBP.' })
      return
    }
    if (f.size > MAX_AVATAR_SIZE) {
      setMessage({ ok: false, text: 'Image trop volumineuse (max 2 Mo).' })
      return
    }
    setAvatarFile(f)
    setAvatarPreview(URL.createObjectURL(f))
  }

  const save = async (e: React.FormEvent) => {
    e.preventDefault()
    setMessage(null)
    if (!validators.fullName(fullName)) return setMessage({ ok: false, text: 'Nom complet invalide.' })
    if (!validators.username(username))
      return setMessage({ ok: false, text: 'Pseudonyme invalide (3-20 caractères : a-z, 0-9, _).' })
    if (bio.length > 300) return setMessage({ ok: false, text: 'Biographie trop longue (max 300).' })

    setSaving(true)
    const { error } = await updateProfile(
      user.id,
      { full_name: fullName.trim(), username, bio, avatarFile },
      profile.avatar_url
    )
    setSaving(false)
    if (error) return setMessage({ ok: false, text: error })
    setAvatarFile(null)
    await refreshProfile()
    setMessage({ ok: true, text: 'Profil mis à jour ✅' })
  }

  const changePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setPassMsg(null)
    if (!validators.password(newPass)) return setPassMsg({ ok: false, text: 'Minimum 8 caractères.' })
    if (newPass !== confirmPass) return setPassMsg({ ok: false, text: 'Les mots de passe ne correspondent pas.' })
    setChangingPass(true)
    const { error } = await updatePassword(newPass)
    setChangingPass(false)
    if (error) return setPassMsg({ ok: false, text: error })
    setNewPass('')
    setConfirmPass('')
    setPassMsg({ ok: true, text: 'Mot de passe modifié ✅' })
  }

  const logout = async () => {
    await signOut()
    navigate('/login')
  }

  return (
    <div className="mx-auto max-w-xl space-y-5">
      <h1 className="text-2xl font-extrabold text-white">Paramètres du profil</h1>

      <Card className="p-6">
        <form onSubmit={save} className="space-y-5">
          {/* Avatar */}
          <div className="flex items-center gap-4">
            <div className="relative">
              <Avatar
                name={fullName || profile.full_name}
                src={avatarPreview ?? profile.avatar_url}
                size={80}
              />
              <button
                type="button"
                onClick={() => fileRef.current?.click()}
                className="absolute -bottom-1 -right-1 flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white shadow-glow transition-transform hover:scale-110"
                title="Changer la photo"
              >
                <Camera size={15} />
              </button>
              <input
                ref={fileRef}
                type="file"
                accept="image/jpeg,image/png,image/webp"
                hidden
                onChange={(e) => pickAvatar(e.target.files?.[0] ?? null)}
              />
            </div>
            <div>
              <p className="font-bold text-white">Photo de profil</p>
              <p className="text-xs text-slate-500">JPG, PNG ou WEBP · 2 Mo maximum</p>
            </div>
          </div>

          <Input label="Nom complet" value={fullName} onChange={(e) => setFullName(e.target.value)} maxLength={60} />
          <Input
            label="Pseudonyme unique"
            value={username}
            onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, '_'))}
            maxLength={20}
          />
          <Textarea
            label="Biographie"
            rows={4}
            value={bio}
            onChange={(e) => setBio(e.target.value)}
            maxLength={300}
            placeholder="Parlez de vous en quelques lignes…"
          />
          <p className="text-xs text-slate-600">Identifiant unique : <code className="text-primary-300">{user.id}</code></p>

          {message && (
            <div
              className={`flex items-center gap-2 rounded-xl p-3 text-sm ${
                message.ok ? 'bg-emerald-500/10 text-emerald-300' : 'bg-rose-500/10 text-rose-300'
              }`}
            >
              {message.ok ? <CheckCircle2 size={16} /> : <AlertCircle size={16} />} {message.text}
            </div>
          )}

          <Button type="submit" disabled={saving} className="w-full" size="lg">
            {saving ? <Loader2 size={18} className="animate-spin" /> : 'Enregistrer les modifications'}
          </Button>
        </form>
      </Card>

      <Card className="p-6">
        <h2 className="flex items-center gap-2 font-bold text-white">
          <KeyRound size={17} className="text-primary-400" /> Changer le mot de passe
        </h2>
        <form onSubmit={changePassword} className="mt-4 space-y-4">
          <Input
            type="password"
            label="Nouveau mot de passe"
            value={newPass}
            onChange={(e) => setNewPass(e.target.value)}
            autoComplete="new-password"
          />
          <Input
            type="password"
            label="Confirmer"
            value={confirmPass}
            onChange={(e) => setConfirmPass(e.target.value)}
            autoComplete="new-password"
          />
          {passMsg && (
            <p className={`text-sm ${passMsg.ok ? 'text-emerald-300' : 'text-rose-300'}`}>{passMsg.text}</p>
          )}
          <Button type="submit" variant="secondary" disabled={changingPass}>
            {changingPass ? <Loader2 size={16} className="animate-spin" /> : 'Mettre à jour'}
          </Button>
        </form>
      </Card>

      <Card className="flex items-center justify-between p-6">
        <div>
          <p className="font-bold text-white">Session</p>
          <p className="text-sm text-slate-500">Connecté(e) en tant que {user.email}</p>
        </div>
        <Button variant="danger" onClick={logout}>
          <LogOut size={16} /> Déconnexion
        </Button>
      </Card>

      <p className="flex items-center justify-center gap-1.5 pb-4 text-xs text-slate-600">
        <ShieldCheck size={13} className="text-emerald-500" /> Données protégées par les politiques RLS Supabase
      </p>
    </div>
  )
}
