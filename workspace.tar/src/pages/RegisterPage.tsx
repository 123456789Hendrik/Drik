import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { User, AtSign, Mail, Lock, Eye, EyeOff, Loader2, Sparkles, AlertCircle, CheckCircle2 } from 'lucide-react'
import { signUp } from '../services/authService'
import { isSupabaseConfigured } from '../services/supabase'
import { validators } from '../utils/helpers'
import { Button, Input } from '../components/ui'

export default function RegisterPage() {
  const navigate = useNavigate()
  const [fullName, setFullName] = useState('')
  const [username, setUsername] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  const fieldErrors: Record<string, string> = {}
  if (fullName && !validators.fullName(fullName)) fieldErrors.fullName = 'Entre 2 et 60 caractères.'
  if (username && !validators.username(username))
    fieldErrors.username = '3-20 caractères : lettres minuscules, chiffres, underscore.'
  if (email && !validators.email(email)) fieldErrors.email = 'Email invalide.'
  if (password && !validators.password(password)) fieldErrors.password = 'Minimum 8 caractères.'
  if (confirm && confirm !== password) fieldErrors.confirm = 'Les mots de passe ne correspondent pas.'

  const submit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (!isSupabaseConfigured) {
      setError('Supabase non configuré. Renseignez le fichier .env (voir README).')
      return
    }
    if (!validators.fullName(fullName)) return setError('Nom complet invalide (2 à 60 caractères).')
    if (!validators.username(username))
      return setError('Pseudonyme invalide : 3-20 caractères (a-z, 0-9, _).')
    if (!validators.email(email)) return setError('Adresse email invalide.')
    if (!validators.password(password)) return setError('Le mot de passe doit contenir au moins 8 caractères.')
    if (password !== confirm) return setError('Les mots de passe ne correspondent pas.')

    setLoading(true)
    const { error } = await signUp({ fullName, username, email, password })
    setLoading(false)
    if (error) return setError(error)
    setSuccess(true)
    // Si la confirmation d'email est désactivée dans Supabase, on redirige automatiquement
    setTimeout(() => navigate('/'), 1500)
  }

  if (success) {
    return (
      <div className="flex min-h-screen flex-col items-center justify-center gap-4 bg-night px-4 text-center text-slate-100">
        <CheckCircle2 size={56} className="text-emerald-400 animate-pop" />
        <h2 className="text-2xl font-bold text-white">Compte créé 🎉</h2>
        <p className="max-w-sm text-sm text-slate-500">
          Si la confirmation d'email est activée sur votre projet Supabase, vérifiez votre boîte mail.
          Sinon, redirection vers votre fil…
        </p>
        <Button onClick={() => navigate('/')}>Accéder à NEXORA</Button>
      </div>
    )
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-night px-4 py-10 text-slate-100">
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 right-1/3 h-[420px] w-[420px] rounded-full bg-secondary/20 blur-[140px]" />
        <div className="absolute bottom-0 left-1/4 h-[380px] w-[380px] rounded-full bg-primary/20 blur-[140px]" />
      </div>

      <div className="relative w-full max-w-md animate-fade-up">
        <div className="mb-8 flex flex-col items-center gap-3 text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary to-secondary text-white shadow-glow">
            <Sparkles size={30} />
          </span>
          <h1 className="bg-gradient-to-r from-primary-400 via-violet-300 to-secondary-400 bg-clip-text text-4xl font-extrabold tracking-tight text-transparent">
            NEXORA
          </h1>
          <p className="text-sm text-slate-500">Rejoignez la communauté.</p>
        </div>

        <div className="rounded-3xl border border-edge bg-card/80 p-7 shadow-card backdrop-blur-xl">
          <h2 className="text-xl font-bold text-white">Créer un compte</h2>
          <p className="mt-1 text-sm text-slate-500">C'est gratuit et ça prend 30 secondes.</p>

          {error && (
            <div className="mt-4 flex items-start gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-300 animate-fade-in">
              <AlertCircle size={17} className="mt-0.5 shrink-0" /> {error}
            </div>
          )}

          <form onSubmit={submit} className="mt-5 space-y-4">
            <div className="relative">
              <User size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                placeholder="Ada Lovelace"
                label="Nom complet"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                error={fieldErrors.fullName}
                className="pl-11"
                maxLength={60}
              />
            </div>
            <div className="relative">
              <AtSign size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                placeholder="ada"
                label="Pseudonyme unique"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/\s/g, '_'))}
                error={fieldErrors.username}
                className="pl-11"
                maxLength={20}
              />
            </div>
            <div className="relative">
              <Mail size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                type="email"
                placeholder="adresse@email.com"
                label="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                error={fieldErrors.email}
                className="pl-11"
                autoComplete="email"
              />
            </div>
            <div className="relative">
              <Lock size={16} className="absolute left-4 top-[38px] text-slate-500" />
              <Input
                type={showPass ? 'text' : 'password'}
                placeholder="••••••••"
                label="Mot de passe"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                error={fieldErrors.password}
                className="pl-11 pr-11"
                autoComplete="new-password"
              />
              <button
                type="button"
                onClick={() => setShowPass((v) => !v)}
                className="absolute right-3.5 top-[34px] text-slate-500 hover:text-slate-300"
              >
                {showPass ? <EyeOff size={17} /> : <Eye size={17} />}
              </button>
            </div>
            <Input
              type={showPass ? 'text' : 'password'}
              placeholder="Confirmez le mot de passe"
              label="Confirmation"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              error={fieldErrors.confirm}
              autoComplete="new-password"
            />

            <Button type="submit" disabled={loading} className="w-full" size="lg">
              {loading ? <Loader2 size={18} className="animate-spin" /> : 'Créer mon compte'}
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-slate-500">
            Déjà membre ?{' '}
            <Link to="/login" className="font-bold text-primary-400 transition-colors hover:text-primary-300">
              Se connecter
            </Link>
          </p>
        </div>
      </div>
    </div>
  )
}
