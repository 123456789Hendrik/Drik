import { useCallback, useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import {
  CalendarDays,
  MessageSquarePlus,
  UserPlus,
  UserCheck,
  FileText,
  Loader2,
  Settings,
  ArrowLeft,
} from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { getProfileByUsername } from '../services/authService'
import { getUserPosts } from '../services/postService'
import { getProfileStats, isFollowing, toggleFollow } from '../services/followService'
import { findOrCreateConversation } from '../services/messageService'
import { createNotification } from '../services/notificationService'
import type { Post, Profile } from '../types'
import Avatar from '../components/Avatar'
import PostCard from '../components/PostCard'
import { Button, Card, EmptyState, Spinner } from '../components/ui'
import { formatDateTime } from '../utils/helpers'

export default function ProfilePage({ username: propUsername }: { username?: string }) {
  const params = useParams()
  const username = propUsername ?? params.username
  const { user, profile: myProfile } = useAuth()
  const navigate = useNavigate()

  const [profile, setProfile] = useState<Profile | null>(null)
  const [stats, setStats] = useState({ posts: 0, followers: 0, following: 0 })
  const [posts, setPosts] = useState<Post[]>([])
  const [following, setFollowing] = useState(false)
  const [loading, setLoading] = useState(true)
  const [followBusy, setFollowBusy] = useState(false)
  const [msgBusy, setMsgBusy] = useState(false)

  const isMe = user?.id === profile?.id

  const load = useCallback(async () => {
    if (!username) return
    setLoading(true)
    const p = await getProfileByUsername(username)
    setProfile(p)
    if (p) {
      const [s, postList, isFol] = await Promise.all([
        getProfileStats(p.id),
        getUserPosts(p.id, user?.id ?? null),
        user ? isFollowing(user.id, p.id) : Promise.resolve(false),
      ])
      setStats(s)
      setPosts(postList)
      setFollowing(isFol)
    }
    setLoading(false)
  }, [username, user])

  useEffect(() => {
    load()
  }, [load])

  const handleFollow = async () => {
    if (!user || !profile) return
    setFollowBusy(true)
    const { following: nowFollowing, error } = await toggleFollow(user.id, profile.id)
    setFollowBusy(false)
    if (error) return
    setFollowing(nowFollowing)
    setStats((s) => ({ ...s, followers: s.followers + (nowFollowing ? 1 : -1) }))
    if (nowFollowing) {
      createNotification({ user_id: profile.id, actor_id: user.id, type: 'follow' })
    }
  }

  const handleMessage = async () => {
    if (!user || !profile) return
    setMsgBusy(true)
    const { conversationId, error } = await findOrCreateConversation(user.id, profile.id)
    setMsgBusy(false)
    if (!error && conversationId) navigate(`/messages/${conversationId}`)
  }

  if (loading) {
    return (
      <div className="flex justify-center py-24">
        <Spinner className="h-10 w-10" />
      </div>
    )
  }

  if (!profile) {
    return (
      <Card className="p-8 text-center">
        <p className="text-lg font-bold text-white">Profil introuvable</p>
        <p className="mt-1 text-sm text-slate-500">@{username} n'existe pas (ou plus).</p>
        <Link to="/" className="mt-4 inline-flex items-center gap-1.5 text-sm font-semibold text-primary-400 hover:text-primary-300">
          <ArrowLeft size={15} /> Retour au fil
        </Link>
      </Card>
    )
  }

  return (
    <div className="space-y-5">
      {/* Bandeau profil */}
      <Card className="overflow-hidden">
        <div className="h-28 bg-gradient-to-r from-primary via-violet-600 to-secondary sm:h-36" />
        <div className="px-5 pb-5 sm:px-7">
          <div className="-mt-12 flex items-end justify-between sm:-mt-14">
            <div className="rounded-full ring-4 ring-card">
              <Avatar name={profile.full_name} src={profile.avatar_url} size={96} />
            </div>
            <div className="flex gap-2 pb-1">
              {isMe ? (
                <Button variant="secondary" onClick={() => navigate('/settings')}>
                  <Settings size={16} /> Modifier le profil
                </Button>
              ) : (
                <>
                  <Button variant="secondary" onClick={handleMessage} disabled={msgBusy}>
                    {msgBusy ? <Loader2 size={16} className="animate-spin" /> : <MessageSquarePlus size={16} />}
                    Message
                  </Button>
                  <Button
                    variant={following ? 'outline' : 'primary'}
                    onClick={handleFollow}
                    disabled={followBusy}
                  >
                    {followBusy ? (
                      <Loader2 size={16} className="animate-spin" />
                    ) : following ? (
                      <UserCheck size={16} />
                    ) : (
                      <UserPlus size={16} />
                    )}
                    {following ? 'Abonné(e)' : 'Suivre'}
                  </Button>
                </>
              )}
            </div>
          </div>

          <div className="mt-3">
            <h1 className="text-xl font-extrabold text-white sm:text-2xl">{profile.full_name}</h1>
            <p className="text-sm text-slate-500">@{profile.username}</p>
            {profile.bio && <p className="mt-2.5 whitespace-pre-wrap text-sm leading-relaxed text-slate-300">{profile.bio}</p>}
            <p className="mt-2.5 flex items-center gap-1.5 text-xs text-slate-600">
              <CalendarDays size={13} /> Membre depuis {formatDateTime(profile.created_at).split(' à ')[0]}
            </p>
          </div>

          <div className="mt-5 grid grid-cols-3 divide-x divide-edge rounded-2xl border border-edge bg-night/40">
            {[
              { label: 'Publications', value: stats.posts },
              { label: 'Abonnés', value: stats.followers },
              { label: 'Abonnements', value: stats.following },
            ].map((s) => (
              <div key={s.label} className="py-3.5 text-center">
                <p className="text-lg font-extrabold text-white">{s.value}</p>
                <p className="text-xs font-medium uppercase tracking-wide text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>
        </div>
      </Card>

      {/* Publications */}
      <h2 className="px-1 pt-1 text-sm font-bold uppercase tracking-wider text-slate-500">
        <FileText size={14} className="mr-1.5 inline" />
        Publications
      </h2>
      {posts.length === 0 ? (
        <Card>
          <EmptyState
            icon={<FileText size={26} />}
            title={isMe ? 'Vous n\'avez rien publié' : 'Aucune publication'}
            subtitle={isMe ? 'Partagez votre premier moment depuis le fil d\'actualité.' : undefined}
          />
        </Card>
      ) : (
        posts.map((post) => <PostCard key={post.id} post={post} onChanged={load} />)
      )}
    </div>
  )
}
