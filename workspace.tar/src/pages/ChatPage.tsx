import { useCallback, useEffect, useRef, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { ArrowLeft, Send, Loader2, Play, Pause, Volume2, Check, CheckCheck } from 'lucide-react'
import { supabase } from '../services/supabase'
import { useAuth } from '../contexts/AuthContext'
import {
  getMessages,
  sendTextMessage,
  sendAudioMessage,
  getAudioUrl,
  markMessagesRead,
  getConversations,
} from '../services/messageService'
import { createNotification } from '../services/notificationService'
import type { Message, Profile } from '../types'
import Avatar from '../components/Avatar'
import VoiceRecorder from '../components/VoiceRecorder'
import { Spinner } from '../components/ui'
import { formatTime, formatDuration, cn } from '../utils/helpers'

/** Bulle de message vocal avec lecture via URL signée. */
function AudioBubble({ msg, mine }: { msg: Message; mine: boolean }) {
  const [url, setUrl] = useState<string | null>(null)
  const [failed, setFailed] = useState(false)
  const [playing, setPlaying] = useState(false)
  const audioRef = useRef<HTMLAudioElement | null>(null)

  useEffect(() => {
    let cancelled = false
    if (msg.audio_path)
      getAudioUrl(msg.audio_path).then((u) => {
        if (!cancelled) {
          if (u) setUrl(u)
          else setFailed(true)
        }
      })
    return () => {
      cancelled = true
    }
  }, [msg.audio_path])

  const toggle = () => {
    if (!audioRef.current) return
    if (audioRef.current.paused) {
      audioRef.current.play()
      setPlaying(true)
    } else {
      audioRef.current.pause()
      setPlaying(false)
    }
  }

  return (
    <div className={cn('flex items-center gap-2.5', mine && 'flex-row-reverse')}>
      <button
        onClick={toggle}
        disabled={!url}
        className={cn(
          'flex h-9 w-9 shrink-0 items-center justify-center rounded-full transition-transform active:scale-90 disabled:opacity-50',
          mine ? 'bg-white/20 text-white' : 'bg-primary/30 text-primary-200'
        )}
      >
        {url ? playing ? <Pause size={15} /> : <Play size={15} /> : <Loader2 size={15} className="animate-spin" />}
      </button>
      {url && (
        <audio
          ref={audioRef}
          src={url}
          onEnded={() => setPlaying(false)}
          className="hidden"
          preload="metadata"
        />
      )}
      <div className="flex items-center gap-[3px]">
        {Array.from({ length: 16 }).map((_, i) => (
          <span
            key={i}
            className={cn('w-1 rounded-full', mine ? 'bg-white/60' : 'bg-primary-300/70')}
            style={{ height: `${5 + ((i * 13) % 14)}px` }}
          />
        ))}
      </div>
      <span className="text-xs font-semibold opacity-80">
        {failed ? '⚠️' : formatDuration(msg.duration ?? 0)}
      </span>
      {failed && <Volume2 size={14} className="opacity-70" />}
    </div>
  )
}

export default function ChatPage() {
  const { conversationId } = useParams()
  const { user, profile } = useAuth()
  const navigate = useNavigate()
  const [messages, setMessages] = useState<Message[]>([])
  const [other, setOther] = useState<Profile | null>(null)
  const [loading, setLoading] = useState(true)
  const [input, setInput] = useState('')
  const [sending, setSending] = useState(false)
  const [peerTyping, setPeerTyping] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null)

  const scrollBottom = useCallback(() => {
    setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'smooth' }), 50)
  }, [])

  // Chargement initial + abonnements Realtime
  useEffect(() => {
    if (!conversationId || !user) return
    let unsubscribed = false
    let removeRealtime: (() => void) | null = null

    ;(async () => {
      const convs = await getConversations(user.id)
      const conv = convs.find((c) => c.id === conversationId)
      if (unsubscribed) return
      if (!conv) {
        // Vérifie qu'on est bien participant avant d'afficher la conversation
        const { data } = await supabase
          .from('conversation_participants')
          .select('user_id')
          .eq('conversation_id', conversationId)
        const ids = (data ?? []).map((d) => d.user_id as string)
        if (!ids.includes(user.id)) {
          navigate('/messages')
          return
        }
        setOther(convs.flatMap((c) => c.participant_profiles ?? []).find((p) => p.id !== user.id) ?? null)
      } else {
        setOther(conv.participant_profiles?.find((p) => p.id !== user.id) ?? null)
      }

      const msgs = await getMessages(conversationId)
      if (unsubscribed) return
      setMessages(msgs)
      setLoading(false)
      scrollBottom()
      markMessagesRead(conversationId, user.id)

      // Realtime : nouveaux messages + statut lu
      const channel = supabase
        .channel(`chat-${conversationId}`)
        .on(
          'postgres_changes',
          { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
          (payload) => {
            const m = payload.new as Message
            setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]))
            scrollBottom()
            if (m.sender_id !== user.id) {
              markMessagesRead(conversationId, user.id)
              createNotification({
                user_id: m.sender_id,
                actor_id: user.id,
                type: 'message',
                conversation_id: conversationId,
              })
            }
          }
        )
        .on(
          'postgres_changes',
          { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${conversationId}` },
          (payload) => {
            const m = payload.new as Message
            setMessages((prev) => prev.map((x) => (x.id === m.id ? { ...x, read_by: m.read_by } : x)))
          }
        )
        .subscribe()
      removeRealtime = () => supabase.removeChannel(channel)
    })()

    return () => {
      unsubscribed = true
      removeRealtime?.()
    }
  }, [conversationId, user, navigate, scrollBottom])

  // Indicateur de saisie (Realtime presence)
  useEffect(() => {
    if (!conversationId || !user) return
    const ch = supabase.channel(`typing-${conversationId}`, {
      config: { presence: { key: user.id } },
    })
    ch.on('presence', { event: 'sync' }, () => {
      const states = ch.presenceState()
      const typingOthers = Object.keys(states).filter((k) => k !== user.id && (states[k] as { typing?: boolean }[])[0]?.typing)
      setPeerTyping(typingOthers.length > 0)
    }).subscribe()
    channelRef.current = ch
    return () => {
      supabase.removeChannel(ch)
      channelRef.current = null
    }
  }, [conversationId, user])

  const broadcastTyping = (isTyping: boolean) => {
    channelRef.current?.track({ typing: isTyping }).catch(() => {})
  }

  const send = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user || !conversationId || !input.trim() || sending) return
    setSending(true)
    broadcastTyping(false)
    const { error } = await sendTextMessage(conversationId, user.id, input)
    setSending(false)
    if (!error) {
      setInput('')
      // L'ajout réel arrive par Realtime ; fallback si le diff ne remonte pas sender
      const msgs = await getMessages(conversationId)
      setMessages((prev) => {
        const merged = new Map(prev.map((m) => [m.id, m]))
        for (const m of msgs) merged.set(m.id, m)
        return Array.from(merged.values()).sort((a, b) => a.created_at.localeCompare(b.created_at))
      })
      scrollBottom()
    }
  }

  const sendVoice = async (blob: Blob, duration: number) => {
    if (!user || !conversationId) return
    await sendAudioMessage(conversationId, user.id, blob, duration)
    const msgs = await getMessages(conversationId)
    setMessages(msgs)
    scrollBottom()
  }

  if (loading) {
    return (
      <div className="flex h-[70vh] items-center justify-center">
        <Spinner className="h-9 w-9" />
      </div>
    )
  }

  return (
    <div className="flex h-[calc(100dvh-8.5rem)] flex-col overflow-hidden rounded-2xl border border-edge bg-card shadow-card lg:h-[calc(100dvh-7rem)]">
      {/* En-tête */}
      <div className="flex items-center gap-3 border-b border-edge bg-card/95 px-4 py-3 backdrop-blur">
        <button onClick={() => navigate('/messages')} className="rounded-xl p-1.5 text-slate-400 hover:bg-cardlight hover:text-white">
          <ArrowLeft size={19} />
        </button>
        <Link to={other ? `/u/${other.username}` : '#'} className="flex min-w-0 items-center gap-3">
          <Avatar name={other?.full_name ?? '?'} src={other?.avatar_url} size={40} />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-white">{other?.full_name ?? 'Conversation'}</p>
            <p className="truncate text-xs text-slate-500">
              {peerTyping ? (
                <span className="text-primary-300 animate-pulse-soft">en train d'écrire…</span>
              ) : other ? (
                `@${other.username}`
              ) : null}
            </p>
          </div>
        </Link>
      </div>

      {/* Messages */}
      <div className="flex-1 space-y-1.5 overflow-y-auto px-4 py-4">
        {messages.length === 0 && (
          <p className="py-10 text-center text-sm text-slate-600">
            Démarrez la conversation 👋 — texte ou message vocal 🎤
          </p>
        )}
        {messages.map((m, i) => {
          const mine = m.sender_id === user?.id
          const showAvatar = !mine && (i === 0 || messages[i - 1]?.sender_id !== m.sender_id)
          const prev = messages[i - 1]
          const showDate =
            !prev || new Date(prev.created_at).toDateString() !== new Date(m.created_at).toDateString()
          return (
            <div key={m.id}>
              {showDate && (
                <p className="my-3 text-center text-[11px] font-medium text-slate-600">
                  {new Date(m.created_at).toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' })}
                </p>
              )}
              <div className={cn('flex items-end gap-2', mine ? 'justify-end' : 'justify-start')}>
                {!mine && (
                  <div className="w-7 shrink-0">
                    {showAvatar && <Avatar name={profile?.full_name ?? '?'} src={undefined} size={28} />}
                  </div>
                )}
                <div
                  className={cn(
                    'max-w-[78%] animate-fade-up rounded-2xl px-3.5 py-2.5 text-sm shadow-sm',
                    mine
                      ? 'rounded-br-md bg-gradient-to-br from-primary to-secondary text-white'
                      : 'rounded-bl-md bg-cardlight text-slate-100 ring-1 ring-edge'
                  )}
                >
                  {m.type === 'audio' ? (
                    <AudioBubble msg={m} mine={mine} />
                  ) : (
                    <p className="whitespace-pre-wrap break-words">{m.content}</p>
                  )}
                  <div className={cn('mt-1 flex items-center gap-1 text-[10px]', mine ? 'justify-end text-white/70' : 'text-slate-500')}>
                    {formatTime(m.created_at)}
                    {mine &&
                      ((m.read_by ?? []).length > 0 ? (
                        <CheckCheck size={12} className="text-emerald-300" />
                      ) : (
                        <Check size={12} />
                      ))}
                  </div>
                </div>
              </div>
            </div>
          )
        })}
        {peerTyping && (
          <div className="flex items-center gap-1.5 px-2 py-1 text-xs text-slate-500">
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-primary" />
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-primary [animation-delay:200ms]" />
            <span className="h-1.5 w-1.5 animate-pulse-soft rounded-full bg-primary [animation-delay:400ms]" />
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Composeur */}
      <form onSubmit={send} className="flex items-center gap-2 border-t border-edge bg-night/40 px-3 py-2.5">
        <input
          value={input}
          onChange={(e) => {
            setInput(e.target.value)
            if (e.target.value.length === 1) broadcastTyping(true)
          }}
          onBlur={() => broadcastTyping(false)}
          onKeyDown={(e) => {
            if (input.length > 0 && e.key === 'Backspace' && !input.slice(0, e.currentTarget.selectionStart ?? 0).trim())
              broadcastTyping(false)
          }}
          placeholder="Votre message…"
          maxLength={4000}
          className="flex-1 rounded-full border border-edge bg-card px-4 py-2.5 text-sm text-white placeholder-slate-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        <VoiceRecorder onSend={sendVoice} />
        <button
          type="submit"
          disabled={sending || !input.trim()}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-gradient-to-r from-primary to-secondary text-white shadow-glow transition-all hover:brightness-110 active:scale-90 disabled:opacity-40"
        >
          {sending ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}
        </button>
      </form>
    </div>
  )
}
