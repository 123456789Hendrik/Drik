import { useCallback, useEffect, useRef, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Loader2, Plus, MessageCircle } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { searchProfiles } from '../services/authService'
import { findOrCreateConversation, getConversations } from '../services/messageService'
import type { Conversation, Profile } from '../types'
import Avatar from '../components/Avatar'
import { Card, EmptyState, Spinner } from '../components/ui'
import { timeAgo, cn } from '../utils/helpers'

export default function MessagesListPage() {
  const { user } = useAuth()
  const navigate = useNavigate()
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [loading, setLoading] = useState(true)
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Profile[] | null>(null)
  const [searching, setSearching] = useState(false)
  const [creating, setCreating] = useState<string | null>(null)

  const load = useCallback(async () => {
    if (!user) return
    const convs = await getConversations(user.id)
    setConversations(convs)
    setLoading(false)
  }, [user])

  useEffect(() => {
    load()
    const t = setInterval(load, 15_000) // rafraîchissement léger (derniers messages)
    return () => clearInterval(t)
  }, [load])

  const runSearch = async (q: string) => {
    setQuery(q)
    if (q.trim().length < 2) {
      setResults(null)
      return
    }
    setSearching(true)
    let r = await searchProfiles(q, 10)
    r = r.filter((p) => p.id !== user?.id)
    setResults(r)
    setSearching(false)
  }

  const startConversation = async (otherId: string) => {
    if (!user) return
    setCreating(otherId)
    const { conversationId, error } = await findOrCreateConversation(user.id, otherId)
    setCreating(null)
    if (!error && conversationId) {
      setQuery('')
      setResults(null)
      navigate(`/messages/${conversationId}`)
    }
  }

  const otherOf = (c: Conversation): Profile | undefined =>
    c.participant_profiles?.find((p) => p.id !== user?.id) ?? c.participant_profiles?.[0]

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold text-white">Messages</h1>
        <p className="mt-1 text-sm text-slate-500">Vos conversations privées — texte & vocal.</p>
      </div>

      {/* Nouvelle conversation via recherche */}
      <div className="relative">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          value={query}
          onChange={(e) => runSearch(e.target.value)}
          placeholder="Rechercher un membre pour discuter…"
          className="w-full rounded-2xl border border-edge bg-card py-3 pl-11 pr-4 text-sm text-white placeholder-slate-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
        {results && query.trim().length >= 2 && (
          <Card className="absolute z-30 mt-2 max-h-72 w-full overflow-y-auto">
            {searching ? (
              <div className="flex justify-center p-4"><Spinner /></div>
            ) : results.length === 0 ? (
              <p className="p-4 text-center text-sm text-slate-500">Aucun membre trouvé.</p>
            ) : (
              results.map((p) => (
                <button
                  key={p.id}
                  onClick={() => startConversation(p.id)}
                  disabled={creating === p.id}
                  className="flex w-full items-center gap-3 border-b border-edge/40 px-4 py-3 text-left transition-colors last:border-0 hover:bg-cardlight"
                >
                  <Avatar name={p.full_name} src={p.avatar_url} size={38} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold text-white">{p.full_name}</p>
                    <p className="truncate text-xs text-slate-500">@{p.username}</p>
                  </div>
                  {creating === p.id ? (
                    <Loader2 size={16} className="animate-spin text-primary-400" />
                  ) : (
                    <Plus size={16} className="text-primary-400" />
                  )}
                </button>
              ))
            )}
          </Card>
        )}
      </div>

      {/* Liste des conversations */}
      {loading ? (
        <div className="flex justify-center py-16"><Spinner className="h-8 w-8" /></div>
      ) : conversations.length === 0 ? (
        <Card>
          <EmptyState
            icon={<MessageCircle size={26} />}
            title="Aucune conversation"
            subtitle="Recherchez un membre ci-dessus pour démarrer une discussion privée."
          />
        </Card>
      ) : (
        <Card className="divide-y divide-edge/50 overflow-hidden">
          {conversations.map((c) => {
            const other = otherOf(c)
            const last = c.last_message
            const unread =
              last && user && last.sender_id !== user.id && !(last.read_by ?? []).includes(user.id)
            return (
              <button
                key={c.id}
                onClick={() => navigate(`/messages/${c.id}`)}
                className={cn(
                  'flex w-full items-center gap-3.5 px-4 py-3.5 text-left transition-colors hover:bg-cardlight',
                  unread && 'bg-primary/5'
                )}
              >
                <Avatar name={other?.full_name ?? '?'} src={other?.avatar_url} size={50} />
                <div className="min-w-0 flex-1">
                  <div className="flex items-baseline justify-between gap-2">
                    <p className={cn('truncate text-sm', unread ? 'font-extrabold text-white' : 'font-bold text-slate-200')}>
                      {other?.full_name ?? 'Conversation'}
                    </p>
                    {last && <span className="shrink-0 text-[11px] text-slate-600">{timeAgo(last.created_at)}</span>}
                  </div>
                  <p className={cn('mt-0.5 truncate text-xs', unread ? 'font-semibold text-primary-200' : 'text-slate-500')}>
                    {last
                      ? last.type === 'audio'
                        ? `🎤 Message vocal (${last.duration ?? 0}s)`
                        : (last.sender_id === user?.id ? 'Vous : ' : '') + last.content
                      : 'Nouvelle conversation'}
                  </p>
                </div>
                {unread && <span className="h-2.5 w-2.5 shrink-0 animate-pulse-soft rounded-full bg-gradient-to-r from-primary to-secondary" />}
              </button>
            )
          })}
        </Card>
      )}
    </div>
  )
}
