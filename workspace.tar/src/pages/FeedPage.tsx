import { useCallback, useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Globe2, Users, Loader2, FileText, AlertTriangle } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { getFeed } from '../services/postService'
import type { Post } from '../types'
import PostCard, { PostComposer } from '../components/PostCard'
import { Card, EmptyState, Spinner } from '../components/ui'
import { cn } from '../utils/helpers'
import { isSupabaseConfigured } from '../services/supabase'

const PAGE_SIZE = 10

export default function FeedPage() {
  const { user } = useAuth()
  const [params] = useSearchParams()
  const highlightPost = params.get('post')
  const [tab, setTab] = useState<'all' | 'following'>('all')
  const [posts, setPosts] = useState<Post[]>([])
  const [page, setPage] = useState(0)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [hasMore, setHasMore] = useState(true)
  const sentinelRef = useRef<HTMLDivElement>(null)
  const loadingRef = useRef(false)

  const load = useCallback(
    async (p: number, replace: boolean) => {
      if (loadingRef.current) return
      loadingRef.current = true
      p === 0 ? setLoading(true) : setLoadingMore(true)
      const data = await getFeed(user?.id ?? null, p, PAGE_SIZE, tab === 'following')
      setPosts((prev) => (replace ? data : [...prev, ...data]))
      setHasMore(data.length === PAGE_SIZE)
      setLoading(false)
      setLoadingMore(false)
      loadingRef.current = false
    },
    [user, tab]
  )

  useEffect(() => {
    setPage(0)
    load(0, true)
  }, [load])

  // Chargement progressif (infinite scroll)
  useEffect(() => {
    const el = sentinelRef.current
    if (!el) return
    const obs = new IntersectionObserver(
      (entries) => {
        if (entries[0]?.isIntersecting && hasMore && !loading && !loadingMore) {
          setPage((p) => {
            const next = p + 1
            load(next, false)
            return next
          })
        }
      },
      { rootMargin: '400px' }
    )
    obs.observe(el)
    return () => obs.disconnect()
  }, [hasMore, loading, loadingMore, load])

  const refresh = () => load(0, true)

  if (!isSupabaseConfigured) {
    return (
      <Card className="p-6">
        <div className="flex items-start gap-3 text-sm text-amber-300">
          <AlertTriangle size={22} className="mt-0.5 shrink-0" />
          <div>
            <p className="font-bold">Configuration requise</p>
            <p className="mt-1 text-slate-400">
              L'application n'est pas encore connectée à Supabase. Copiez <code className="rounded bg-night px-1.5 py-0.5 text-primary-300">.env.example</code> vers{' '}
              <code className="rounded bg-night px-1.5 py-0.5 text-primary-300">.env</code>, renseignez votre URL et votre clé anon, exécutez le script{' '}
              <code className="rounded bg-night px-1.5 py-0.5 text-primary-300">supabase/schema.sql</code>, puis rechargez la page.
              Les instructions complètes sont dans le README.md.
            </p>
          </div>
        </div>
      </Card>
    )
  }

  return (
    <div className="space-y-5">
      {/* Onglets */}
      <div className="flex rounded-2xl border border-edge bg-card p-1.5">
        {(
          [
            { id: 'all', label: 'Pour vous', icon: Globe2 },
            { id: 'following', label: 'Abonnements', icon: Users },
          ] as const
        ).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={cn(
              'flex flex-1 items-center justify-center gap-2 rounded-xl py-2.5 text-sm font-bold transition-all duration-200',
              tab === t.id
                ? 'bg-gradient-to-r from-primary to-secondary text-white shadow-glow'
                : 'text-slate-400 hover:bg-cardlight hover:text-white'
            )}
          >
            <t.icon size={16} /> {t.label}
          </button>
        ))}
      </div>

      <PostComposer onCreated={refresh} />

      {loading ? (
        <div className="flex justify-center py-16">
          <Spinner className="h-9 w-9" />
        </div>
      ) : posts.length === 0 ? (
        <Card>
          <EmptyState
            icon={<FileText size={26} />}
            title={tab === 'following' ? 'Aucune publication d\'abonnés' : 'Le fil est vide pour l\'instant'}
            subtitle={
              tab === 'following'
                ? 'Suivez des personnes depuis la page Découvrir pour voir leurs publications ici.'
                : 'Soyez le premier à partager quelque chose !'
            }
          />
        </Card>
      ) : (
        <>
          {posts.map((post) => (
            <PostCard
              key={post.id}
              post={post}
              onChanged={refresh}
              highlight={highlightPost === post.id}
            />
          ))}
          <div ref={sentinelRef} className="h-4" />
          {loadingMore && (
            <div className="flex justify-center py-6">
              <Loader2 className="animate-spin text-primary-400" size={26} />
            </div>
          )}
          {!hasMore && posts.length > 0 && (
            <p className="py-6 text-center text-sm text-slate-600">— Vous avez tout vu ✨ —</p>
          )}
        </>
      )}
    </div>
  )
}
