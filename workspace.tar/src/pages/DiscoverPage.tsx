import { useCallback, useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { Compass, Loader2, UserPlus, UserCheck, Flame } from 'lucide-react'
import { useAuth } from '../contexts/AuthContext'
import { searchProfiles } from '../services/authService'
import { getSuggestions, toggleFollow, isFollowing } from '../services/followService'
import { createNotification } from '../services/notificationService'
import type { Profile } from '../types'
import Avatar from '../components/Avatar'
import PostCard from '../components/PostCard'
import { getRecentPosts } from '../services/postService'
import type { Post } from '../types'
import { Card, EmptyState, Spinner } from '../components/ui'

export default function DiscoverPage() {
  const { user } = useAuth()
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Profile[] | null>(null)
  const [searching, setSearching] = useState(false)
  const [suggestions, setSuggestions] = useState<Profile[]>([])
  const [followedIds, setFollowedIds] = useState<Set<string>>(new Set())
  const [busyId, setBusyId] = useState<string | null>(null)
  const [recentPosts, setRecentPosts] = useState<Post[]>([])
  const [loadingPosts, setLoadingPosts] = useState(true)

  const loadAll = useCallback(async () => {
    if (!user) return
    const [sugg, posts] = await Promise.all([getSuggestions(user.id, 6), getRecentPosts(user.id, 15)])
    setSuggestions(sugg)
    setRecentPosts(posts)
    const followStates = await Promise.all(sugg.map((p) => isFollowing(user.id, p.id)))
    setFollowedIds(new Set(sugg.filter((_, i) => followStates[i]).map((p) => p.id)))
    setLoadingPosts(false)
  }, [user])

  useEffect(() => {
    loadAll()
  }, [loadAll])

  const runSearch = async (q: string) => {
    setQuery(q)
    if (q.trim().length < 2) {
      setResults(null)
      return
    }
    setSearching(true)
    const r = await searchProfiles(q, 15)
    setResults(r)
    setSearching(false)
  }

  const handleFollow = async (profile: Profile) => {
    if (!user) return
    setBusyId(profile.id)
    const { following, error } = await toggleFollow(user.id, profile.id)
    setBusyId(null)
    if (error) return
    setFollowedIds((prev) => {
      const next = new Set(prev)
      following ? next.add(profile.id) : next.delete(profile.id)
      return next
    })
    if (following) createNotification({ user_id: profile.id, actor_id: user.id, type: 'follow' })
  }

  const UserRow = ({ p }: { p: Profile }) => {
    const isFollowed = followedIds.has(p.id)
    return (
      <div className="flex items-center gap-3 border-b border-edge/40 px-4 py-3 last:border-0">
        <Link to={`/u/${p.username}`} className="flex min-w-0 flex-1 items-center gap-3">
          <Avatar name={p.full_name} src={p.avatar_url} size={42} />
          <div className="min-w-0">
            <p className="truncate text-sm font-bold text-white">{p.full_name}</p>
            <p className="truncate text-xs text-slate-500">@{p.username}</p>
          </div>
        </Link>
        {p.id !== user?.id && (
          <button
            onClick={() => handleFollow(p)}
            disabled={busyId === p.id}
            className={`flex shrink-0 items-center gap-1.5 rounded-full px-3.5 py-1.5 text-xs font-bold transition-all active:scale-95 ${
              isFollowed
                ? 'border border-primary/50 text-primary-300 hover:bg-primary/10'
                : 'bg-gradient-to-r from-primary to-secondary text-white shadow-glow hover:brightness-110'
            }`}
          >
            {busyId === p.id ? (
              <Loader2 size={13} className="animate-spin" />
            ) : isFollowed ? (
              <UserCheck size={13} />
            ) : (
              <UserPlus size={13} />
            )}
            {isFollowed ? 'Suivi(e)' : 'Suivre'}
          </button>
        )}
      </div>
    )
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-extrabold text-white">
          <Compass size={24} className="text-primary-400" /> Découvrir
        </h1>
        <p className="mt-1 text-sm text-slate-500">Trouvez des personnes et explorez les publications récentes.</p>
      </div>

      {/* Recherche mobile */}
      <div className="relative lg:hidden">
        <input
          value={query}
          onChange={(e) => runSearch(e.target.value)}
          placeholder="Rechercher un membre…"
          className="w-full rounded-2xl border border-edge bg-card px-4 py-3 text-sm text-white placeholder-slate-500 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/30"
        />
      </div>

      {/* Résultats de recherche */}
      {results && query.trim().length >= 2 && (
        <Card className="overflow-hidden">
          <p className="border-b border-edge px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-500">
            Résultats
          </p>
          {searching ? (
            <div className="flex justify-center p-6"><Spinner /></div>
          ) : results.length === 0 ? (
            <EmptyState icon={<Compass size={24} />} title="Aucun membre trouvé" />
          ) : (
            results.map((p) => <UserRow key={p.id} p={p} />)
          )}
        </Card>
      )}

      {/* Suggestions */}
      {!results && (
        <Card className="overflow-hidden">
          <p className="flex items-center gap-2 border-b border-edge px-4 py-2.5 text-xs font-bold uppercase tracking-wider text-slate-500">
            <Flame size={14} className="text-orange-400" /> Suggestions de comptes
          </p>
          {suggestions.length === 0 ? (
            <EmptyState icon={<UserPlus size={24} />} title="Aucune suggestion" subtitle="D'autres membres rejoindront bientôt NEXORA !" />
          ) : (
            suggestions.map((p) => <UserRow key={p.id} p={p} />)
          )}
        </Card>
      )}

      {/* Publications récentes */}
      <div>
        <h2 className="mb-3 px-1 text-sm font-bold uppercase tracking-wider text-slate-500">Publications récentes</h2>
        {loadingPosts ? (
          <div className="flex justify-center py-12"><Spinner className="h-8 w-8" /></div>
        ) : recentPosts.length === 0 ? (
          <Card>
            <EmptyState icon={<Compass size={24} />} title="Rien à découvrir pour l'instant" subtitle="Les publications apparaîtront ici." />
          </Card>
        ) : (
          <div className="space-y-5">
            {recentPosts.map((post) => (
              <PostCard key={post.id} post={post} onChanged={loadAll} />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
